#!/usr/bin/env python3
"""
FastTag Gemini AI Bridge via WebSocket & HTTP
Supports WebSocket (ws://) which is 100% allowed by Stash's Content-Security-Policy (connect-src ws: wss:)
Zero third-party dependencies - standard library only!
"""
import sys
import os
import json
import socket
import select
import struct
import base64
import hashlib
import urllib.request
import urllib.error
import threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import socketserver

PORT = 9998
WS_MAGIC_STRING = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

def get_runtime_dir():
    dot_stash = os.path.expanduser("~/.stash")
    try:
        os.makedirs(dot_stash, exist_ok=True)
        return dot_stash
    except Exception:
        pass
    plugin_dir = os.path.dirname(os.path.abspath(__file__))
    try:
        test_file = os.path.join(plugin_dir, ".perm_test")
        with open(test_file, "w") as f:
            f.write("")
        os.remove(test_file)
        return plugin_dir
    except Exception:
        pass
    import tempfile
    return tempfile.gettempdir()

LOG_FILE = os.path.join(get_runtime_dir(), "fasttag_gemini_bridge.log")
PID_FILE = os.path.join(get_runtime_dir(), "fasttag_gemini_bridge.pid")

def bridge_log(msg):
    try:
        with open(LOG_FILE, "a") as f:
            tname = getattr(threading.current_thread(), "name", "main")
            f.write(f"[{tname}] {msg}\n")
    except Exception:
        pass

AVAILABLE_MODELS_CACHE = {} # api_key -> list of valid model names

def get_available_models(api_key):
    if api_key in AVAILABLE_MODELS_CACHE:
        return AVAILABLE_MODELS_CACHE[api_key]
    url = f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}"
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=10) as resp:
            resp_data = json.loads(resp.read().decode("utf-8"))
            models = [
                m.get("name", "").replace("models/", "")
                for m in resp_data.get("models", [])
                if "generateContent" in m.get("supportedGenerationMethods", [])
                and not any(bad in m.get("name", "").lower() for bad in ["tts", "audio", "image", "embedding", "aqa", "realtime", "robotics"])
            ]
            AVAILABLE_MODELS_CACHE[api_key] = models
            bridge_log(f"AVAILABLE MODELS FOR KEY: {models}")
            return models
    except Exception as e:
        bridge_log(f"ERROR FETCHING MODELS: {e}")
        return []

def get_ordered_candidate_models(api_key, requested_model=None):
    models = get_available_models(api_key)
    ordered = []

    priority = [
        "gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.5-flash",
        "gemini-2.5-flash-lite", "gemini-3.8-flash", "gemini-3.7-flash",
        "gemini-3.6-flash", "gemini-3.5-flash", "gemini-3.5-flash-lite",
        "gemini-pro-latest"
    ]

    if requested_model and not any(bad in requested_model.lower() for bad in ["tts", "audio", "image", "embedding", "2.0", "1.5", "1.0"]):
        ordered.append(requested_model)

    for p in priority:
        if p not in ordered and (not models or p in models):
            ordered.append(p)

    for m in models:
        if m not in ordered:
            ordered.append(m)

    if not ordered:
        ordered = ["gemini-flash-latest", "gemini-flash-lite-latest", "gemini-3.8-flash", "gemini-3.6-flash"]

    return ordered

SCRIPT_START_MTIME = os.path.getmtime(os.path.abspath(__file__)) if os.path.exists(os.path.abspath(__file__)) else 0

def check_for_script_update():
    """
    Hot-reload guard: if the bridge script on disk was modified (e.g. by a plugin update),
    cleanly removes its PID file and exits so the next request auto-spawns the fresh code.
    Note: the single in-flight request during reload will drop as the socket closes;
    FastTag's frontend WebSocket reconnect automatically restarts the bridge within 800ms.
    """
    global SCRIPT_START_MTIME
    try:
        current_mtime = os.path.getmtime(os.path.abspath(__file__))
        if SCRIPT_START_MTIME and current_mtime > SCRIPT_START_MTIME:
            bridge_log("Detected updated fasttag_gemini_bridge.py on disk. Cleaning up PID and exiting for hot reload...")
            try:
                if os.path.exists(PID_FILE):
                    with open(PID_FILE, "r") as pf:
                        if int(pf.read().strip()) == os.getpid():
                            os.remove(PID_FILE)
            except Exception:
                pass
            os._exit(0)
    except Exception:
        pass

def process_gemini_request(data):
    check_for_script_update()
    req_type = data.get("type", "parse")
    api_key = data.get("api_key", "").strip()
    req_model = data.get("model", "gemini-flash-latest").strip()

    if not api_key:
        return {"error": "No API key provided"}

    candidates = get_ordered_candidate_models(api_key, req_model)

    if req_type == "test":
        # Candidate names can include local fallbacks, so they are not proof that
        # Google accepted the API key. Only report success when listModels returned
        # at least one model from the authenticated Gemini API.
        verified_models = get_available_models(api_key)
        if not verified_models:
            return {"error": "Could not verify Gemini access. Please check your API key and network connection."}
        active_model = req_model if req_model in verified_models else candidates[0]
        return {"status": "ok", "message": f"Connected! Active model: {active_model}", "models": verified_models}

    # Parse request
    filename = data.get("filename", "").strip()
    title = data.get("title", "").strip()
    performers_context = data.get("performers_context", [])
    studios_context = data.get("studios_context", [])

    prompt = f"""You are an expert video metadata extractor and parser.
Analyze this video filename and title:
Filename: "{filename}"
Title: "{title}"

{f'Sample library performers for reference: {json.dumps(performers_context[:150])}' if performers_context else ''}
{f'Sample library studios for reference: {json.dumps(studios_context[:60])}' if studios_context else ''}

Extract and return a valid JSON object matching this schema:
{{
  "clean_title": "Clean, human-readable scene title without technical metadata, video codecs, resolutions, site prefixes, or raw date prefixes",
  "date": "Release date formatted as YYYY-MM-DD (or null if not found)",
  "studio": "Studio, Network, or Website name (or null)",
  "performers": ["Array of performer/actor names extracted from filename or title"],
  "tags": ["Array of descriptive tags/genres/themes (e.g. Twink, Solo, Interview, BDSM, Outdoor)"],
  "confidence": 95
}}"""

    payload = json.dumps({
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"responseMimeType": "application/json", "temperature": 0.1}
    }).encode("utf-8")

    log = bridge_log

    log(f"Received {req_type} request. Model requested: '{req_model}', filename: '{filename}'")

    last_error = None
    import time
    for chosen_model in candidates[:5]: # Try up to 5 models on rate limits
        start_t = time.time()
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{chosen_model}:generateContent?key={api_key}"
        log(f"Attempting model: {chosen_model}...")
        try:
            req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=12) as resp: # 12s resilient timeout
                resp_data = json.loads(resp.read().decode("utf-8"))
                candidates_data = resp_data.get("candidates") or []
                parts = candidates_data[0].get("content", {}).get("parts", []) if candidates_data else []
                raw_text = parts[0].get("text", "") if parts else ""
                if not raw_text.strip():
                    raise ValueError("Gemini returned no JSON content")
                parsed = json.loads(raw_text)
                if not isinstance(parsed, dict):
                    raise ValueError("Gemini returned an invalid metadata response")
                has_suggestion = any([
                    str(parsed.get("clean_title") or "").strip(),
                    str(parsed.get("date") or "").strip(),
                    str(parsed.get("studio") or "").strip(),
                    parsed.get("performers") or [],
                    parsed.get("tags") or [],
                ])
                if not has_suggestion:
                    raise ValueError("Gemini returned no usable metadata suggestions")
                elapsed = time.time() - start_t
                log(f"Model {chosen_model} SUCCEEDED in {elapsed:.2f}s!")
                return {"status": "ok", "result": parsed, "model_used": chosen_model}
        except urllib.error.HTTPError as e:
            elapsed = time.time() - start_t
            err_msg = e.read().decode("utf-8", errors="ignore")
            try:
                err_json = json.loads(err_msg)
                err_msg = err_json.get("error", {}).get("message", err_msg)
            except Exception:
                pass
            last_error = f"Google Gemini API error ({e.code}) on model {chosen_model}: {err_msg}"
            log(f"Model {chosen_model} FAILED ({e.code}) in {elapsed:.2f}s: {err_msg}")
            continue
        except Exception as e:
            elapsed = time.time() - start_t
            last_error = str(e)
            log(f"Model {chosen_model} EXCEPTION in {elapsed:.2f}s: {e}")
            continue

    log(f"All candidates failed. Last error: {last_error}")
    return {"error": last_error or "Google Gemini API did not respond in time"}



def process_ollama_request(req_data):
    """
    Isolated proxy handler for Stash Assistant Ollama requests.
    Completely decoupled from FastTag Gemini pipelines.
    """
    action = req_data.get('action', 'generate')
    endpoint = (req_data.get('endpoint') or 'http://127.0.0.1:11434').rstrip('/')
    timeout_sec = int(req_data.get('timeout_sec', 15))

    try:
        if action in ('tags', 'health'):
            url = f"{endpoint}/api/tags"
            req = urllib.request.Request(url, headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                return {'status': 'ok', 'result': data, 'type': 'stash_assistant_ollama_response'}

        elif action == 'generate':
            url = f"{endpoint}/api/generate"
            payload_data = req_data.get('payload') or {}
            payload_bytes = json.dumps(payload_data).encode('utf-8')
            req = urllib.request.Request(url, data=payload_bytes, headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                return {'status': 'ok', 'result': data, 'type': 'stash_assistant_ollama_response'}

        elif action in ('embeddings', 'embed'):
            url = f"{endpoint}/api/embeddings"
            model = req_data.get('model', 'nomic-embed-text')
            prompt_input = req_data.get('prompt') or req_data.get('input') or ''

            if isinstance(prompt_input, list):
                embeddings_list = []
                for item in prompt_input:
                    payload_bytes = json.dumps({'model': model, 'prompt': str(item)}).encode('utf-8')
                    req = urllib.request.Request(url, data=payload_bytes, headers={'Content-Type': 'application/json'})
                    with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
                        res_data = json.loads(resp.read().decode('utf-8'))
                        embeddings_list.append(res_data.get('embedding', []))
                return {'status': 'ok', 'result': {'embeddings': embeddings_list}, 'type': 'stash_assistant_ollama_response'}
            else:
                payload_bytes = json.dumps({'model': model, 'prompt': str(prompt_input)}).encode('utf-8')
                req = urllib.request.Request(url, data=payload_bytes, headers={'Content-Type': 'application/json'})
                with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
                    data = json.loads(resp.read().decode('utf-8'))
                    return {'status': 'ok', 'result': data, 'type': 'stash_assistant_ollama_response'}

        else:
            return {'error': f'Unknown Ollama action: {action}', 'type': 'stash_assistant_ollama_response'}

    except urllib.error.HTTPError as e:
        err_msg = e.read().decode('utf-8', errors='ignore')
        return {'error': f'Ollama HTTP {e.code}: {err_msg}', 'type': 'stash_assistant_ollama_response'}
    except Exception as e:
        return {'error': f'Ollama connection error: {str(e)}', 'type': 'stash_assistant_ollama_response'}

class DualServerHandler(socketserver.StreamRequestHandler):
    def handle(self):
        # Read HTTP request header
        initial = b""
        while b"\r\n\r\n" not in initial and len(initial) < 4096:
            chunk = self.connection.recv(1024)
            if not chunk:
                return
            initial += chunk

        lines = initial.decode("utf-8", errors="ignore").split("\r\n")
        req_line = lines[0] if lines else ""
        headers = {}
        for line in lines[1:]:
            if ":" in line:
                k, v = line.split(":", 1)
                headers[k.strip().lower()] = v.strip()

        # Check if WebSocket upgrade
        if headers.get("upgrade", "").lower() == "websocket":
            sec_key = headers.get("sec-websocket-key", "")
            if not sec_key:
                return
            accept_val = base64.b64encode(hashlib.sha1(sec_key.encode("utf-8") + WS_MAGIC_STRING).digest()).decode("utf-8")
            response = (
                "HTTP/1.1 101 Switching Protocols\r\n"
                "Upgrade: websocket\r\n"
                "Connection: Upgrade\r\n"
                f"Sec-WebSocket-Accept: {accept_val}\r\n"
                "\r\n"
            )
            self.connection.sendall(response.encode("utf-8"))
            self.handle_websocket()
        else:
            # Handle normal HTTP request (health check / CORS)
            if "OPTIONS" in req_line:
                resp = (
                    "HTTP/1.1 204 No Content\r\n"
                    "Access-Control-Allow-Origin: *\r\n"
                    "Access-Control-Allow-Methods: GET, POST, OPTIONS, HEAD\r\n"
                    "Access-Control-Allow-Headers: *\r\n"
                    "Access-Control-Allow-Private-Network: true\r\n"
                    "\r\n"
                )
                self.connection.sendall(resp.encode("utf-8"))
            else:
                body = json.dumps({"status": "ok", "service": "FastTag Gemini WebSocket Bridge"}).encode("utf-8")
                resp = (
                    "HTTP/1.1 200 OK\r\n"
                    "Content-Type: application/json\r\n"
                    "Access-Control-Allow-Origin: *\r\n"
                    "Access-Control-Allow-Private-Network: true\r\n"
                    f"Content-Length: {len(body)}\r\n"
                    "\r\n"
                ).encode("utf-8") + body
                self.connection.sendall(resp)

    def handle_websocket(self):
        while True:
            try:
                head = self.connection.recv(2)
                if not head or len(head) < 2:
                    break
                b1, b2 = head[0], head[1]
                fin = b1 & 0x80
                opcode = b1 & 0x0f
                if opcode == 8: # Connection close
                    break

                masked = b2 & 0x80
                payload_len = b2 & 0x7f

                if payload_len == 126:
                    ext = self.connection.recv(2)
                    payload_len = struct.unpack("!H", ext)[0]
                elif payload_len == 127:
                    ext = self.connection.recv(8)
                    payload_len = struct.unpack("!Q", ext)[0]

                mask_key = self.connection.recv(4) if masked else None
                payload = b""
                while len(payload) < payload_len:
                    chunk = self.connection.recv(min(4096, payload_len - len(payload)))
                    if not chunk:
                        break
                    payload += chunk

                if masked and mask_key:
                    unmasked = bytearray(payload)
                    for i in range(len(unmasked)):
                        unmasked[i] ^= mask_key[i % 4]
                    payload = bytes(unmasked)

                if opcode == 1: # Text frame
                    req_data = json.loads(payload.decode("utf-8"))
                    req_id = req_data.get("id")
                    if req_data.get("type") == "stash_assistant_ollama":
                        res = process_ollama_request(req_data)
                    else:
                        res = process_gemini_request(req_data)
                    if req_id is not None:
                        res["id"] = req_id

                    # Send response frame
                    resp_bytes = json.dumps(res).encode("utf-8")
                    out_len = len(resp_bytes)
                    if out_len <= 125:
                        out_head = bytes([0x81, out_len])
                    elif out_len <= 65535:
                        out_head = struct.pack("!BBH", 0x81, 126, out_len)
                    else:
                        out_head = struct.pack("!BBQ", 0x81, 127, out_len)

                    self.connection.sendall(out_head + resp_bytes)
            except Exception as e:
                break

class ThreadingTCPServerReuse(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

def run_server():
    server = ThreadingTCPServerReuse(("0.0.0.0", PORT), DualServerHandler)
    print(f"[FastTag Gemini Bridge] WebSocket & HTTP server listening on ws://0.0.0.0:{PORT}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()

if __name__ == "__main__":
    run_server()
