(function initializeFastTagScraperController(root) {
    'use strict';

    let dependencies = null;
    let floatingHudElement = null;
    let floatingHudPosition = null;
    let floatingHudSize = null;
    let floatingHudOwnerPopup = null;
    let floatingHudOwnerObserver = null;
    const sessionCache = new Map();

    function getScraperHeaderDensity(availableWidth) {
        const width = Number(availableWidth);
        return Number.isFinite(width) && width > 0 && width < 410 ? 'tight' : 'normal';
    }

    function configure(options) {
        dependencies = options;
    }

    function isPopupActive(popup) {
        if (!popup) return true;
        return popup === dependencies?.getActivePopup?.()
            && popup._fastTagClosed !== true
            && Boolean(popup.element?.isConnected);
    }

    function beginRequest(popup, sceneId) {
        if (!isPopupActive(popup)) return null;
        const normalizedSceneId = String(sceneId || '');
        if (popup?.currentSceneId != null && String(popup.currentSceneId) !== normalizedSceneId) return null;
        const requestId = Number(popup?._scrapeRequestGeneration || 0) + 1;
        popup._scrapeRequestGeneration = requestId;
        popup._activeScrapeRequest = { requestId, sceneId: normalizedSceneId };
        return requestId;
    }

    function invalidateRequests(popup) {
        if (!popup) return;
        popup._scrapeRequestGeneration = Number(popup._scrapeRequestGeneration || 0) + 1;
        popup._activeScrapeRequest = null;
    }

    function isRequestCurrent(popup, sceneId, requestId = null) {
        if (!isPopupActive(popup)) return false;
        const normalizedSceneId = String(sceneId || '');
        if (popup?.currentSceneId != null && String(popup.currentSceneId) !== normalizedSceneId) return false;
        if (requestId == null) return true;
        return popup?._activeScrapeRequest?.requestId === requestId
            && popup._activeScrapeRequest?.sceneId === normalizedSceneId;
    }

    function watchHudOwner(popup) {
        if (floatingHudOwnerObserver) {
            floatingHudOwnerObserver.disconnect();
            floatingHudOwnerObserver = null;
        }
        floatingHudOwnerPopup = popup || null;
        const ownerParent = popup?.element?.parentNode;
        if (!popup || !ownerParent || typeof root.MutationObserver === 'undefined') return;

        floatingHudOwnerObserver = new root.MutationObserver(() => {
            if (!isPopupActive(popup) && floatingHudOwnerPopup === popup) {
                closeHud();
            }
        });
        floatingHudOwnerObserver.observe(ownerParent, { childList: true });
    }

    function closeHud() {
        if (floatingHudOwnerObserver) {
            floatingHudOwnerObserver.disconnect();
            floatingHudOwnerObserver = null;
        }
        floatingHudOwnerPopup = null;
        if (floatingHudElement) {
            floatingHudElement._fastTagResizeObserver?.disconnect?.();
            floatingHudElement._fastTagScraperHeaderResizeObserver?.disconnect?.();
            floatingHudElement.remove();
            floatingHudElement = null;
        }
    }

    function getInitialPopoutPosition(hudWidth = 390, hudHeight = 480) {
        if (!dependencies) throw new Error('[FastTag] Scraper controller is not configured');
        const document = root.document;
        const activePopup = dependencies.getActivePopup?.();
        const activeForm = activePopup?.element || document.querySelector('#scenes-popup');
        const margin = 12;
        const screenWidth = root.innerWidth;
        const screenHeight = root.innerHeight;

        const videoHudElement = dependencies.getFloatingVideoHudElement?.();
        const isVideoOpen = dependencies.isVideoPoppedOut?.()
            && videoHudElement
            && document.body.contains(videoHudElement);
        const videoRect = isVideoOpen ? videoHudElement.getBoundingClientRect() : null;

        if (activeForm) {
            let rect = activeForm.getBoundingClientRect();
            if (!rect || rect.width <= 0 || rect.left <= 0) {
                const formW = parseInt(activeForm.style?.width, 10) || 760;
                const formH = parseInt(activeForm.style?.height, 10) || 760;
                const defPos = dependencies.getDefaultEverythingPosition(formW, formH);
                rect = { left: defPos.x, right: defPos.x + formW, top: defPos.y, bottom: defPos.y + formH, width: formW, height: formH };
            }

            const spaceRight = Math.max(0, screenWidth - rect.right - margin);
            const spaceLeft = Math.max(0, rect.left - margin);
            if (spaceRight >= hudWidth + margin) {
                const left = Math.round(rect.right + margin);
                const top = Math.max(margin, Math.min(screenHeight - hudHeight - margin, Math.round(rect.top)));
                return { left: `${left}px`, top: `${top}px`, width: `${hudWidth}px`, height: `${hudHeight}px` };
            }
            if (spaceLeft >= hudWidth + margin && (!isVideoOpen || (videoRect && videoRect.left >= rect.right))) {
                const left = Math.round(rect.left - hudWidth - margin);
                const top = Math.max(margin, Math.min(screenHeight - hudHeight - margin, Math.round(rect.top)));
                return { left: `${left}px`, top: `${top}px`, width: `${hudWidth}px`, height: `${hudHeight}px` };
            }
            const left = Math.max(margin, Math.min(screenWidth - hudWidth - margin, Math.round(rect.right + margin)));
            const top = Math.max(margin, Math.min(screenHeight - hudHeight - margin, Math.round(rect.top)));
            return { left: `${left}px`, top: `${top}px`, width: `${hudWidth}px`, height: `${hudHeight}px` };
        }

        return { right: '20px', top: '70px', width: `${hudWidth}px`, height: `${hudHeight}px` };
    }

    function attachResizeHandles(hudElement) {
        if (!hudElement) return;
        const document = root.document;
        hudElement.querySelectorAll('.fasttag-scraper-resize-handle').forEach(element => element.remove());

        const minW = 300;
        const minH = 220;
        const maxW = Math.max(minW, root.innerWidth - 16);
        const maxH = Math.max(minH, root.innerHeight - 16);
        const handles = [
            { dir: 'n', style: 'top: -5px; left: 12px; right: 12px; height: 10px; cursor: ns-resize; z-index: 100;' },
            { dir: 's', style: 'bottom: -5px; left: 12px; right: 12px; height: 10px; cursor: ns-resize; z-index: 100;' },
            { dir: 'e', style: 'right: -5px; top: 12px; bottom: 12px; width: 10px; cursor: ew-resize; z-index: 100;' },
            { dir: 'w', style: 'left: -5px; top: 12px; bottom: 12px; width: 10px; cursor: ew-resize; z-index: 100;' },
            { dir: 'ne', style: 'top: -5px; right: -5px; width: 16px; height: 16px; cursor: nesw-resize; z-index: 101;' },
            { dir: 'nw', style: 'top: -5px; left: -5px; width: 16px; height: 16px; cursor: nwse-resize; z-index: 101;' },
            { dir: 'se', style: 'bottom: -5px; right: -5px; width: 16px; height: 16px; cursor: nwse-resize; z-index: 101;' },
            { dir: 'sw', style: 'bottom: -5px; left: -5px; width: 16px; height: 16px; cursor: nesw-resize; z-index: 101;' }
        ];

        handles.forEach(({ dir, style }) => {
            const handle = document.createElement('div');
            handle.className = 'fasttag-scraper-resize-handle';
            handle.setAttribute('data-dir', dir);
            handle.style.cssText = `position: absolute; ${style} user-select: none; touch-action: none;`;
            handle.addEventListener('mousedown', event => {
                event.preventDefault();
                event.stopPropagation();
                hudElement._isDragging = true;
                const startX = event.clientX;
                const startY = event.clientY;
                const rect = hudElement.getBoundingClientRect();
                const startL = rect.left;
                const startT = rect.top;
                const startW = hudElement.offsetWidth;
                const startH = hudElement.offsetHeight;
                document.body.style.cursor = handle.style.cursor;
                document.body.style.userSelect = 'none';

                const onMouseMove = moveEvent => {
                    const dx = moveEvent.clientX - startX;
                    const dy = moveEvent.clientY - startY;
                    let newW = startW;
                    let newH = startH;
                    let newL = startL;
                    let newT = startT;
                    if (dir.includes('e')) newW = startW + dx;
                    if (dir.includes('w')) { newW = startW - dx; newL = startL + dx; }
                    if (dir.includes('s')) newH = startH + dy;
                    if (dir.includes('n')) { newH = startH - dy; newT = startT + dy; }
                    if (newW < minW) { if (dir.includes('w')) newL = startL + (startW - minW); newW = minW; }
                    if (newW > maxW) { if (dir.includes('w')) newL = startL + (startW - maxW); newW = maxW; }
                    if (newL < 8) { if (dir.includes('w')) newW = startW + (startL - 8); newL = 8; }
                    if (newH < minH) { if (dir.includes('n')) newT = startT + (startH - minH); newH = minH; }
                    if (newH > maxH) { if (dir.includes('n')) newT = startT + (startH - maxH); newH = maxH; }
                    if (newT < 8) { if (dir.includes('n')) newH = startH + (startT - 8); newT = 8; }
                    if (newT + newH > root.innerHeight - 8 && dir.includes('s')) newH = root.innerHeight - 8 - newT;
                    if (newL + newW > root.innerWidth - 8 && dir.includes('e')) newW = root.innerWidth - 8 - newL;
                    hudElement.style.width = `${Math.round(newW)}px`;
                    hudElement.style.height = `${Math.round(newH)}px`;
                    hudElement.style.left = `${Math.round(newL)}px`;
                    hudElement.style.top = `${Math.round(newT)}px`;
                    hudElement.style.right = 'auto';
                    floatingHudSize = { width: `${Math.round(newW)}px`, height: `${Math.round(newH)}px` };
                    floatingHudPosition = { top: `${Math.round(newT)}px`, left: `${Math.round(newL)}px` };
                    // The result header has its own compact layout. Re-evaluate it
                    // from the live HUD width instead of waiting for ResizeObserver,
                    // which can miss intermediate sizes during a fast drag.
                    hudElement._fastTagRecheckScraperHeaderLayout?.();
                };

                const onMouseUp = () => {
                    hudElement._isDragging = false;
                    document.removeEventListener('mousemove', onMouseMove);
                    document.removeEventListener('mouseup', onMouseUp);
                    document.body.style.cursor = '';
                    document.body.style.userSelect = '';
                    try {
                        root.localStorage.setItem('fasttag_scraper_hud_pos', JSON.stringify(floatingHudPosition));
                        root.localStorage.setItem('fasttag_scraper_hud_size', JSON.stringify(floatingHudSize));
                    } catch (error) {}
                    hudElement._fastTagRecheckScraperHeaderLayout?.();
                };
                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            });
            hudElement.appendChild(handle);
        });
    }

    function attachHudDragging(hudElement, headerElement) {
        if (!hudElement || !headerElement) return;
        const document = root.document;
        headerElement.style.cursor = 'grab';
        let isDragging = false;
        let startX = 0, startY = 0, startL = 0, startT = 0;
        const onMouseMove = event => {
            if (!isDragging || !hudElement) return;
            const newLeft = Math.max(8, Math.min(root.innerWidth - hudElement.offsetWidth - 8, startL + event.clientX - startX));
            const newTop = Math.max(8, Math.min(root.innerHeight - hudElement.offsetHeight - 8, startT + event.clientY - startY));
            hudElement.style.left = `${newLeft}px`;
            hudElement.style.top = `${newTop}px`;
            hudElement.style.right = 'auto';
            const position = { top: `${newTop}px`, left: `${newLeft}px` };
            setHudPosition(position);
            try {
                root.localStorage.setItem('fasttag_scraper_hud_pos', JSON.stringify(position));
            } catch (error) {}
        };
        const onMouseUp = () => {
            isDragging = false;
            hudElement._isDragging = false;
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
            document.body.style.userSelect = '';
            headerElement.style.cursor = 'grab';
        };
        headerElement.onmousedown = event => {
            if (event.target.closest?.('button, a, input, select')) return;
            const rect = hudElement.getBoundingClientRect();
            isDragging = true;
            hudElement._isDragging = true;
            startX = event.clientX;
            startY = event.clientY;
            startL = rect.left;
            startT = rect.top;
            headerElement.style.cursor = 'grabbing';
            document.body.style.userSelect = 'none';
            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        };
    }

    function getHudElement() { return floatingHudElement; }
    function setHudElement(element) { floatingHudElement = element || null; }
    function getHudPosition() { return floatingHudPosition; }
    function setHudPosition(position) { floatingHudPosition = position || null; }
    function getHudSize() { return floatingHudSize; }
    function setHudSize(size) { floatingHudSize = size || null; }
    function getHudOwnerPopup() { return floatingHudOwnerPopup; }
    function isHudOpen() { return Boolean(floatingHudElement && root.document?.body?.contains(floatingHudElement)); }
    function resetLayoutState() { floatingHudPosition = null; floatingHudSize = null; }

    
    function attachSourceDropdown(triggerBtn, popup, sceneId, onSourceChange) {
        if (!triggerBtn) return;
        triggerBtn.addEventListener("click", async (event) => {
            event.preventDefault();
            event.stopPropagation();

            const existingMenu = root.document.getElementById("fasttag-source-dropdown-menu");
            if (existingMenu) {
                existingMenu.remove();
                return;
            }

            const isDark = typeof dependencies?.getEffectiveTheme === "function" ? dependencies.getEffectiveTheme() === "dark" : true;
            const sources = typeof dependencies?.loadScraperSources === "function"
                ? await dependencies.loadScraperSources()
                : { stashBoxes: [], scrapers: [], all: [] };
            const activeSource = typeof dependencies?.resolveActiveSource === "function"
                ? dependencies.resolveActiveSource(sources, popup?._selectedScraperSource || dependencies?.getActiveScraperSource?.() || null)
                : (sources.all?.[0] || { id: "stashbox_0", name: "StashDB.org" });
            const escapeFn = typeof dependencies?.escapeHtml === "function" ? dependencies.escapeHtml : (s => String(s || ""));

            const menu = root.document.createElement("div");
            menu.id = "fasttag-source-dropdown-menu";
            menu.style.cssText = "position: fixed; z-index: 10000002; background: " + (isDark ? "#0f172a" : "#ffffff") + "; border: 1px solid " + (isDark ? "rgba(129, 140, 248, 0.45)" : "#a5b4fc") + "; border-radius: 8px; box-shadow: 0 10px 30px rgba(0,0,0,0.6); padding: 6px; min-width: 220px; max-width: 280px; max-height: 360px; font-family: system-ui, -apple-system, sans-serif; font-size: 11px; box-sizing: border-box; display: flex; flex-direction: column; gap: 4px; overflow: hidden;";

            const rect = triggerBtn.getBoundingClientRect();
            let top = rect.bottom + 4;
            let left = rect.left;
            if (top + 360 > root.innerHeight) top = Math.max(8, rect.top - 365);
            if (left + 260 > root.innerWidth) left = Math.max(8, root.innerWidth - 270);
            menu.style.top = top + "px";
            menu.style.left = left + "px";

            // Prevent clicks, mousedown, or wheel from triggering outside handlers or Stash actions
            menu.addEventListener("mousedown", (e) => e.stopPropagation());
            menu.addEventListener("click", (e) => e.stopPropagation());
            menu.addEventListener("wheel", (e) => e.stopPropagation(), { passive: false });

            let html = `
                <div style="padding: 1px 2px 4px 2px; border-bottom: 1px solid ${isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)"}; flex-shrink: 0;">
                    <input id="fasttag-source-search-input" type="text" placeholder="Search scrapers…" autocomplete="off" style="width: 100%; box-sizing: border-box; height: 26px; padding: 3px 8px; border-radius: 5px; border: 1px solid ${isDark ? "rgba(129, 140, 248, 0.45)" : "#a5b4fc"}; background: ${isDark ? "#1e293b" : "#f1f5f9"}; color: ${isDark ? "#e0e7ff" : "#1e293b"}; font-size: 11px; outline: none;">
                </div>
                <div id="fasttag-source-list-scroll" style="overflow-y: auto; max-height: 290px; display: flex; flex-direction: column; gap: 2px; padding-right: 2px;">
            `;

            if (sources.stashBoxes && sources.stashBoxes.length > 0) {
                html += `<div class="fasttag-source-section-header" data-section="stashbox" style="padding: 4px 6px 2px 6px; font-size: 9px; font-weight: 800; color: ${isDark ? "#818cf8" : "#4f46e5"}; letter-spacing: 0.5px; text-transform: uppercase;">Stash-box Endpoints</div>`;
                sources.stashBoxes.forEach(box => {
                    const isSelected = activeSource.id === box.id || activeSource.index === box.index;
                    html += `
                        <div class="fasttag-source-menu-item" data-source-id="${escapeFn(box.id)}" data-source-name="${escapeFn(box.name).toLowerCase()}" data-source-type="stashbox" style="padding: 5px 7px; border-radius: 5px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; gap: 6px; background: ${isSelected ? (isDark ? "rgba(99, 102, 241, 0.25)" : "rgba(99, 102, 241, 0.15)") : "transparent"}; color: ${isSelected ? (isDark ? "#e0e7ff" : "#312e81") : (isDark ? "#cbd5e1" : "#334155")}; font-weight: ${isSelected ? "700" : "500"}; transition: background 0.1s ease;">
                            <span style="display: flex; align-items: center; gap: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                <span>🌐</span><span title="${escapeFn(box.name)}">${escapeFn(box.name)}</span>
                            </span>
                            ${isSelected ? '<span style="color:#6366f1; font-weight:800; font-size:12px;">✓</span>' : ''}
                        </div>
                    `;
                });
            }

            if (sources.scrapers && sources.scrapers.length > 0) {
                html += `<div class="fasttag-source-section-sep" style="height: 1px; background: ${isDark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)"}; margin: 3px 0;"></div>`;
                html += `<div class="fasttag-source-section-header" data-section="installed" style="padding: 4px 6px 2px 6px; font-size: 9px; font-weight: 800; color: ${isDark ? "#94a3b8" : "#64748b"}; letter-spacing: 0.5px; text-transform: uppercase;">Installed Scrapers</div>`;
                sources.scrapers.forEach(scraper => {
                    const isSelected = activeSource.id === scraper.id || activeSource.scraperId === scraper.scraperId;
                    const isUrlOnly = scraper.isUrlOnly === true;
                    const icon = isUrlOnly ? "🔗" : "⚡";
                    const badge = isUrlOnly
                        ? `<span style="font-size: 8px; font-weight: 700; padding: 1.5px 5px; border-radius: 4px; background: ${isDark ? "rgba(56, 189, 248, 0.18)" : "rgba(14, 165, 233, 0.15)"}; color: ${isDark ? "#38bdf8" : "#0284c7"}; text-transform: uppercase; letter-spacing: 0.5px; flex-shrink: 0;">URL Only</span>`
                        : "";
                    html += `
                        <div class="fasttag-source-menu-item" data-source-id="${escapeFn(scraper.id)}" data-source-name="${escapeFn(scraper.name).toLowerCase()}" data-source-type="installed" style="padding: 5px 7px; border-radius: 5px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; gap: 6px; background: ${isSelected ? (isDark ? "rgba(99, 102, 241, 0.25)" : "rgba(99, 102, 241, 0.15)") : "transparent"}; color: ${isSelected ? (isDark ? "#e0e7ff" : "#312e81") : (isDark ? "#cbd5e1" : "#334155")}; font-weight: ${isSelected ? "700" : "500"}; transition: background 0.1s ease;">
                            <span style="display: flex; align-items: center; gap: 5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1;">
                                <span style="font-size: 11px;">${icon}</span><span title="${escapeFn(scraper.name)}">${escapeFn(scraper.name)}</span>
                            </span>
                            <span style="display: flex; align-items: center; gap: 4px; flex-shrink: 0;">
                                ${badge}
                                ${isSelected ? '<span style="color:#6366f1; font-weight:800; font-size:12px;">✓</span>' : ''}
                            </span>
                        </div>
                    `;
                });
            }

            html += `
                <div id="fasttag-source-empty-msg" style="display: none; padding: 10px 8px; text-align: center; color: ${isDark ? "#94a3b8" : "#64748b"}; font-size: 10.5px;">No scrapers found</div>
                </div>
            `;

            menu.innerHTML = html;
            root.document.body.appendChild(menu);

            const searchInput = menu.querySelector("#fasttag-source-search-input");
            const items = menu.querySelectorAll(".fasttag-source-menu-item");
            const emptyMsg = menu.querySelector("#fasttag-source-empty-msg");
            const sep = menu.querySelector(".fasttag-source-section-sep");
            const headerBox = menu.querySelector('[data-section="stashbox"]');
            const headerInstalled = menu.querySelector('[data-section="installed"]');

            if (searchInput) {
                searchInput.addEventListener("input", () => {
                    const q = (searchInput.value || "").trim().toLowerCase();
                    let visibleBox = 0;
                    let visibleInstalled = 0;

                    items.forEach(item => {
                        const name = (item.dataset.sourceName || "").toLowerCase();
                        const matches = !q || name.includes(q);
                        item.style.display = matches ? "flex" : "none";
                        if (matches) {
                            if (item.dataset.sourceType === "stashbox") visibleBox += 1;
                            else visibleInstalled += 1;
                        }
                    });

                    if (headerBox) headerBox.style.display = visibleBox > 0 ? "block" : "none";
                    if (headerInstalled) headerInstalled.style.display = visibleInstalled > 0 ? "block" : "none";
                    if (sep) sep.style.display = (visibleBox > 0 && visibleInstalled > 0) ? "block" : "none";
                    if (emptyMsg) emptyMsg.style.display = (visibleBox + visibleInstalled) === 0 ? "block" : "none";
                });

                searchInput.addEventListener("keydown", (e) => {
                    e.stopPropagation();
                    if (e.key === "Escape") {
                        e.preventDefault();
                        menu.remove();
                    } else if (e.key === "Enter") {
                        e.preventDefault();
                        for (let i = 0; i < items.length; i++) {
                            if (items[i].style.display !== "none") {
                                items[i].click();
                                break;
                            }
                        }
                    }
                });

                setTimeout(() => searchInput.focus(), 30);
            }

            const closeOnOutside = (e) => {
                if (!menu.contains(e.target) && e.target !== triggerBtn && !triggerBtn.contains(e.target)) {
                    menu.remove();
                    root.document.removeEventListener("mousedown", closeOnOutside);
                }
            };
            setTimeout(() => root.document.addEventListener("mousedown", closeOnOutside), 0);

            items.forEach(item => {
                item.addEventListener("mouseenter", () => {
                    item.style.background = isDark ? "rgba(99, 102, 241, 0.35)" : "rgba(99, 102, 241, 0.2)";
                });
                item.addEventListener("mouseleave", () => {
                    const id = item.dataset.sourceId;
                    const isSelected = activeSource.id === id || activeSource.scraperId === id;
                    item.style.background = isSelected ? (isDark ? "rgba(99, 102, 241, 0.25)" : "rgba(99, 102, 241, 0.15)") : "transparent";
                });
                item.addEventListener("click", (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    const sourceId = item.dataset.sourceId;
                    menu.remove();
                    root.document.removeEventListener("mousedown", closeOnOutside);
                    if (typeof onSourceChange === "function") {
                        onSourceChange(sourceId);
                    }
                });
            });
        });
    }

    function ensureHud(popup) {
        const document = root.document;
        let hudElement = getHudElement();
        if (hudElement && document.body.contains(hudElement)) {
            watchHudOwner(popup);
            return hudElement;
        }

        hudElement = document.createElement('div');
        setHudElement(hudElement);
        hudElement.id = 'fasttag-floating-scraper-hud';
        const defaultPos = getInitialPopoutPosition(390, 480);
        let finalWidth = defaultPos.width || '390px';
        let finalHeight = defaultPos.height || '480px';
        let finalLeft = defaultPos.left;
        let finalTop = defaultPos.top;
        let finalRight = defaultPos.right;

        let savedPos = getHudPosition();
        if (!savedPos) {
            try {
                savedPos = JSON.parse(root.localStorage.getItem('fasttag_scraper_hud_pos') || 'null');
            } catch (error) {}
        }
        let savedSize = getHudSize();
        if (!savedSize) {
            try {
                savedSize = JSON.parse(root.localStorage.getItem('fasttag_scraper_hud_size') || 'null');
            } catch (error) {}
        }

        if (savedPos && savedPos.left && savedPos.top) {
            const pLeft = parseInt(savedPos.left, 10);
            const pTop = parseInt(savedPos.top, 10);
            const savedWidth = savedSize?.width ? parseInt(savedSize.width, 10) : NaN;
            const savedHeight = savedSize?.height ? parseInt(savedSize.height, 10) : NaN;
            const pW = Number.isFinite(savedWidth) && savedWidth >= 300 ? savedWidth : (parseInt(defaultPos.width, 10) || 390);
            const pH = Number.isFinite(savedHeight) && savedHeight >= 220 ? savedHeight : (parseInt(defaultPos.height, 10) || 480);
            if (!isNaN(pLeft) && !isNaN(pTop)) {
                finalLeft = `${Math.max(8, Math.min(root.innerWidth - pW - 8, pLeft))}px`;
                finalTop = `${Math.max(8, Math.min(root.innerHeight - pH - 8, pTop))}px`;
                finalRight = null;
                finalWidth = `${pW}px`;
                finalHeight = `${pH}px`;
                setHudPosition({ left: finalLeft, top: finalTop });
                if (savedSize) setHudSize(savedSize);
            }
        }

        const isDarkTheme = dependencies.getEffectiveTheme() === 'dark';
        const animateHudEntrance = !root.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
        hudElement._fastTagEntrancePending = animateHudEntrance;
        hudElement.style.cssText = `position: fixed; top: ${finalTop}; ${finalLeft ? `left: ${finalLeft};` : `right: ${finalRight};`} width: ${finalWidth}; height: ${finalHeight}; min-width: 300px; min-height: 220px; max-width: 92vw; max-height: 92vh; z-index: 1000000; background: ${isDarkTheme ? '#1e293b' : '#ffffff'}; border: 1.5px solid ${isDarkTheme ? '#4338ca' : '#a5b4fc'}; border-radius: 10px; box-shadow: 0 20px 50px rgba(0,0,0,0.85); overflow: visible; display: flex; flex-direction: column;${animateHudEntrance ? ' opacity:0;' : ''}`;
        document.body.appendChild(hudElement);
        if (animateHudEntrance) {
            const revealHud = () => {
                if (!hudElement?.isConnected) return;
                hudElement.style.opacity = '1';
                hudElement.animate?.([
                    { opacity: 0, transform: 'scale(.985)' },
                    { opacity: 1, transform: 'scale(1)' }
                ], { duration: 160, easing: 'ease-out' });
                hudElement._fastTagEntrancePending = false;
            };
            if (typeof root.requestAnimationFrame === 'function') root.requestAnimationFrame(revealHud);
            else root.setTimeout(revealHud, 0);
        }

        if (typeof root.ResizeObserver === 'function') {
            const scraperResizeObserver = new root.ResizeObserver(() => {
                // This observer owns the actual floating shell, so it is the most
                // reliable signal when host-theme or native resizing changes width.
                hudElement._fastTagRecheckScraperHeaderLayout?.();
                if (hudElement?.isConnected && !hudElement._isDragging && !hudElement._fastTagIdleSizing
                    && hudElement.offsetWidth >= 300 && hudElement.offsetHeight >= 220) {
                    const currentSize = {
                        width: `${hudElement.offsetWidth}px`,
                        height: `${hudElement.offsetHeight}px`
                    };
                    setHudSize(currentSize);
                    try {
                        root.localStorage.setItem('fasttag_scraper_hud_size', JSON.stringify(currentSize));
                    } catch (error) {}
                }
            });
            hudElement._fastTagResizeObserver = scraperResizeObserver;
            scraperResizeObserver.observe(hudElement);
        }
        watchHudOwner(popup);
        return hudElement;
    }

    function showLoadingState(popup, message = 'Scraping new scene…', onAbortAndSearch = null, onCancel = null, onClose = null) {
        if (!isPopupActive(popup)) return false;
        const existingHud = getHudElement();
        if (existingHud?._fastTagIdleSizing) {
            const savedHeight = getHudSize()?.height;
            existingHud._fastTagIdleSizing = false;
            existingHud.style.height = existingHud._fastTagNormalHeight || (typeof savedHeight === 'number' ? `${savedHeight}px` : savedHeight) || '480px';
            delete existingHud._fastTagNormalHeight;
        }
        popup._fastTagScraperIdle = false;
        const detachedHud = dependencies?.getDetachScraper?.()
            ? ensureHud(popup)
            : (isHudOpen() ? getHudElement() : null);
        const targetContainer = detachedHud || popup?.scraperCardContainer;
        if (!targetContainer) return false;

        if (detachedHud && popup?.scraperCardContainer) {
            popup.scraperCardContainer.innerHTML = '';
            popup.scraperCardContainer.style.display = 'none';
        }

        const isDark = dependencies?.getEffectiveTheme?.() !== 'light';
        targetContainer.style.display = 'flex';
        targetContainer.innerHTML = `
            ${detachedHud ? `<div id="fasttag-scrape-loading-header" style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-shrink:0;min-height:38px;padding:8px 12px;border-bottom:1px solid ${isDark ? '#334155' : '#e2e8f0'};background:${isDark ? '#0f172a' : '#f8fafc'};color:${isDark ? '#e0e7ff' : '#312e81'};font-size:11.5px;font-weight:700;user-select:none;"><span>⚡ Searching for a match…</span><span id="fasttag-scrape-loading-actions" style="display:inline-flex;align-items:center;gap:7px;"><span style="color:${isDark ? '#64748b' : '#94a3b8'};font-size:9.5px;font-weight:600;">Drag to move</span><button id="fasttag-scrape-loading-close" type="button" title="Cancel search" style="display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:5px;border:none;background:transparent;color:${isDark ? '#94a3b8' : '#64748b'};font-size:13px;font-weight:700;cursor:pointer;line-height:1;">✕</button></span></div>` : ''}
            <div data-fasttag-scrape-loading="true" role="status" aria-live="polite" style="box-sizing: border-box; width: 100%; min-height: 190px; flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 9px; padding: 24px ${onAbortAndSearch ? '24px 8px' : '24px'}; overflow: hidden; background: ${isDark ? '#1e293b' : '#ffffff'}; color: ${isDark ? '#cbd5e1' : '#475569'};">
                <div aria-hidden="true" style="position: relative; width: 190px; height: 75px; display: flex; align-items: flex-end; justify-content: center; overflow: hidden;">
                    <div class="fasttag-scrape-lens" style="position: absolute; top: 14px; left: calc(50% - 17px); z-index: 3; font-size: 31px; line-height: 1; filter: drop-shadow(0 5px 8px rgba(15,23,42,.3));">🔍</div>
                    <div class="fasttag-scrape-files" style="position: relative; z-index: 1; display: flex; align-items: center; gap: 8px; padding-bottom: 5px;">
                        <span style="display:grid;place-items:center;width:31px;height:25px;border-radius:5px;background:${isDark ? '#334155' : '#e2e8f0'};box-shadow:0 3px 8px rgba(15,23,42,.18);font-size:15px;">🎞️</span>
                        <span style="display:grid;place-items:center;width:35px;height:29px;border-radius:6px;background:${isDark ? '#312e81' : '#e0e7ff'};box-shadow:0 4px 10px rgba(79,70,229,.24);font-size:16px;">▶️</span>
                        <span style="display:grid;place-items:center;width:31px;height:25px;border-radius:5px;background:${isDark ? '#334155' : '#e2e8f0'};box-shadow:0 3px 8px rgba(15,23,42,.18);font-size:15px;">📼</span>
                    </div>
                </div>
                <span style="font-size: 13px; font-weight: 700; letter-spacing: .01em;">${message}</span>
                <span style="max-width: 280px; text-align: center; font-size: 10.5px; line-height: 1.4; color: ${isDark ? '#94a3b8' : '#64748b'};">Checking fingerprints, titles and scene details for the strongest match.</span>
            </div>
            ${(onAbortAndSearch || onCancel) ? `
            <div style="flex-shrink:0;display:flex;align-items:center;gap:6px;padding:8px 12px 10px;border-top:1px solid ${isDark ? '#1e293b' : '#f1f5f9'};background:${isDark ? '#0f172a' : '#f8fafc'};">
                ${onAbortAndSearch ? `
                <input id="fasttag-loading-abort-query" type="text" placeholder="Skip — type to search now…" style="flex:1;min-width:0;height:28px;box-sizing:border-box;padding:3px 9px;border-radius:6px;border:1px solid ${isDark ? 'rgba(129,140,248,0.5)' : '#a5b4fc'};background:${isDark ? '#1e293b' : '#ffffff'};color:${isDark ? '#e2e8f0' : '#1e293b'};font-size:10.5px;outline:none;" aria-label="Type a search term to skip the automatic search">
                <button id="fasttag-loading-abort-btn" type="button" style="height:28px;padding:3px 10px;border-radius:6px;border:1px solid rgba(129,140,248,0.55);background:rgba(99,102,241,0.22);color:${isDark ? '#c7d2fe' : '#4338ca'};font-size:10px;font-weight:700;cursor:pointer;white-space:nowrap;flex-shrink:0;">Search</button>
                ` : '<span style="flex:1;"></span>'}
                <button id="fasttag-loading-cancel-btn" type="button" style="height:28px;padding:3px 10px;border-radius:6px;border:1px solid ${isDark ? 'rgba(239,68,68,0.4)' : '#fca5a5'};background:${isDark ? 'rgba(239,68,68,0.15)' : '#fee2e2'};color:${isDark ? '#fca5a5' : '#b91c1c'};font-size:10px;font-weight:700;cursor:pointer;white-space:nowrap;flex-shrink:0;">Cancel</button>
            </div>` : ''}
        `;
        if (detachedHud) {
            dependencies.mountMomentaryPeekButton?.(detachedHud, detachedHud.querySelector?.('#fasttag-scrape-loading-actions'));
            attachHudDragging(detachedHud, detachedHud.querySelector?.('#fasttag-scrape-loading-header'));
            attachResizeHandles(detachedHud);
        }
        // Close action (header ✕ button closes HUD/window)
        const doClose = () => {
            invalidateRequests(popup);
            root._fastTagEverythingScraperOpen = false;
            if (typeof dependencies?.setScraperHudPersistedOpen === 'function') dependencies.setScraperHudPersistedOpen(false);
            closeHud();
            if (popup?.scraperCardContainer) {
                popup.scraperCardContainer.innerHTML = '';
                popup.scraperCardContainer.style.display = 'none';
            }
            if (popup?.scrapeBtn) {
                popup.scrapeBtn.disabled = false;
                popup.scrapeBtn.classList.remove('fasttag-dock-pulse');
                popup.scrapeBtn.innerHTML = dependencies?.isEasterEggActive?.() ? '<span>⚡ Scrape 🍫</span>' : '<span>⚡ Scrape</span>';
            }
            if (typeof onClose === 'function') onClose();
        };

        // Cancel search action (footer Cancel button stops search and keeps HUD open for manual search)
        const doCancel = () => {
            invalidateRequests(popup);
            if (popup?.scrapeBtn) {
                popup.scrapeBtn.disabled = false;
                popup.scrapeBtn.classList.remove('fasttag-dock-pulse');
                popup.scrapeBtn.innerHTML = dependencies?.isEasterEggActive?.() ? '<span>⚡ Scrape 🍫</span>' : '<span>⚡ Scrape</span>';
            }
            if (typeof onCancel === 'function') {
                onCancel();
            } else {
                renderMatches(targetContainer, [], popup?.currentSceneId, null, popup, null, '', null);
            }
        };

        const headerCloseBtn = targetContainer?.querySelector?.('#fasttag-scrape-loading-close');
        if (headerCloseBtn) {
            headerCloseBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                doClose();
            });
        }
        const cancelBtn = targetContainer?.querySelector?.('#fasttag-loading-cancel-btn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                doCancel();
            });
        }

        // Wire the abort-and-search input if a callback was provided
        if (typeof onAbortAndSearch === 'function' && typeof targetContainer?.querySelector === 'function') {
            const abortInput = targetContainer.querySelector('#fasttag-loading-abort-query');
            const abortBtn = targetContainer.querySelector('#fasttag-loading-abort-btn');
            const doAbortSearch = () => {
                const q = (abortInput?.value || '').trim();
                if (!q) { abortInput?.focus(); return; }
                onAbortAndSearch(q);
            };
            if (abortInput) {
                abortInput.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); doAbortSearch(); }
                });

            }
            if (abortBtn) {
                abortBtn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); doAbortSearch(); });
            }
        }
        if (popup?.scrapeBtn) {
            popup.scrapeBtn.disabled = true;
            popup.scrapeBtn.innerHTML = '<span>⏳ Scraping...</span>';
        }
        return true;
    }

    function refreshIdleSourceBtn(container, explicitSourceId = null) {
        if (!container || !dependencies) return;
        const idleSourceBtn = container.querySelector?.('#fasttag-scrape-idle-source-btn');
        if (!idleSourceBtn) return;
        const nameSpan = idleSourceBtn.querySelector?.('.fasttag-idle-source-name');
        const badgeSpan = idleSourceBtn.querySelector?.('.fasttag-idle-source-badge');

        const updateUI = (source) => {
            if (!source) return;
            const name = source.shortName || source.name || 'StashDB';
            const isUrlOnly = Boolean(source.isUrlOnly);
            const icon = isUrlOnly ? '🔗' : '⚡';
            if (nameSpan) {
                nameSpan.textContent = `${icon} ${name}`;
            }
            if (badgeSpan) {
                badgeSpan.innerHTML = isUrlOnly ? '<span style="font-size: 8px; color: #38bdf8; font-weight: 800; margin-left: 2px;">[URL]</span>' : '';
            }
            idleSourceBtn.title = `Active Scraper: ${name}${isUrlOnly ? ' (URL-only)' : ''} (Click to switch)`;
        };

        const targetSourceId = explicitSourceId || dependencies.getActiveScraperSource?.() || null;
        if (typeof dependencies.loadScraperSources === 'function') {
            dependencies.loadScraperSources().then(sources => {
                const active = typeof dependencies.resolveActiveSource === 'function'
                    ? dependencies.resolveActiveSource(sources, targetSourceId)
                    : (sources?.all?.[0] || { id: 'stashbox_0', name: 'StashDB.org', shortName: 'StashDB' });
                updateUI(active);
            }).catch(() => {});
        }
    }

    function showAutoScrapeOffState(popup) {
        if (!isPopupActive(popup) || !dependencies) return false;
        invalidateRequests(popup);
        const detached = dependencies.getDetachScraper();
        let targetContainer = popup?.scraperCardContainer || null;
        if (!detached) {
            closeHud();
            if (targetContainer) {
                targetContainer.innerHTML = '';
                targetContainer.style.display = 'none';
            }
            popup._fastTagScraperIdle = false;
            if (popup.scrapeBtn) {
                popup.scrapeBtn.classList.remove('fasttag-dock-pulse');
                popup.scrapeBtn.innerHTML = dependencies.isEasterEggActive?.() ? '<span>⚡ Scrape 🍫</span>' : '<span>⚡ Scrape</span>';
                popup.scrapeBtn.title = 'Search this scene manually';
            }
            return true;
        }
        if (targetContainer) {
            targetContainer.innerHTML = '';
            targetContainer.style.display = 'none';
        }
        const hudWasAlreadyOpen = isHudOpen();
        targetContainer = ensureHud(popup);
        watchHudOwner(popup);
        if (!targetContainer) return false;
        if (targetContainer.querySelector?.('[data-fasttag-auto-scrape-off-header]')) {
            popup._fastTagScraperIdle = true;
            if (popup.scrapeBtn) {
                popup.scrapeBtn.classList.toggle('fasttag-dock-pulse', detached);
                popup.scrapeBtn.innerHTML = dependencies.isEasterEggActive?.() ? '<span>⚡ Scrape 🍫</span>' : '<span>⚡ Scrape</span>';
                popup.scrapeBtn.title = 'Search this scene manually';
            }
            refreshIdleSourceBtn(targetContainer, popup._selectedScraperSource);
            return true;
        }
        const isDark = dependencies.getEffectiveTheme?.() !== 'light';
        const border = isDark ? '#334155' : '#d8dee9';
        const headerBg = isDark ? '#0f172a' : '#f8fafc';
        const text = isDark ? '#e2e8f0' : '#26344a';
        targetContainer.style.display = 'flex';
        targetContainer.style.flexDirection = 'column';
        targetContainer.innerHTML = `
            <div data-fasttag-auto-scrape-off-header="true" style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-shrink:0;min-height:38px;padding:6px 10px;border-bottom:1px solid ${border};background:${headerBg};color:${text};font-size:11.5px;font-weight:700;user-select:none;">
                <div style="display:flex;align-items:center;gap:6px;min-width:0;flex:1;">
                    <span style="font-size:11px;font-weight:700;color:${isDark ? '#94a3b8' : '#64748b'};white-space:nowrap;">Scraper:</span>
                    <button type="button" id="fasttag-scrape-idle-source-btn" class="fasttag-source-selector-btn" style="background:${isDark ? 'rgba(99, 102, 241, 0.22)' : 'rgba(99, 102, 241, 0.12)'};border:1px solid ${isDark ? 'rgba(129, 140, 248, 0.5)' : '#818cf8'};border-radius:5px;color:${isDark ? '#e0e7ff' : '#312e81'};font-size:10.5px;font-weight:700;padding:2px 7px;cursor:pointer;display:inline-flex;align-items:center;gap:3px;max-width:145px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:1.3;" title="Choose scraper before scraping (Click to switch)">
                        <span class="fasttag-idle-source-name" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:95px;">⚡ StashDB</span>
                        <span class="fasttag-idle-source-badge"></span>
                        <span style="font-size:8px;opacity:0.7;transform:translateY(0.5px);">▼</span>
                    </button>
                </div>
                <button type="button" data-fasttag-idle-dock-toggle="true" style="padding:3px 7px;border:1px solid ${border};border-radius:4px;background:transparent;color:${text};cursor:pointer;font-size:10px;font-weight:700;flex-shrink:0;">${detached ? 'Dock' : 'Pop out'}</button>
            </div>
            <div style="display:flex;flex:1;min-height:0;align-items:center;justify-content:center;overflow:hidden;background:#111827;">
                <img src="/plugin/fasttag/assets/fasttag-auto-scraping-off.webp" alt="Auto-Scraping Off test card" style="display:block;width:100%;height:100%;object-fit:contain;">
            </div>`;
        if (detached && !targetContainer._fastTagIdleSizing) {
            targetContainer._fastTagNormalHeight = targetContainer.style.height;
            const width = targetContainer.getBoundingClientRect?.()?.width || targetContainer.offsetWidth || 390;
            const fittedHeight = Math.max(220, Math.min(root.innerHeight * 0.92, Math.round(width * 720 / 1279) + 40));
            targetContainer._fastTagIdleSizing = true;
            targetContainer.style.height = `${fittedHeight}px`;
        }
        if (!hudWasAlreadyOpen && !targetContainer._fastTagEntrancePending && !root.matchMedia?.('(prefers-reduced-motion: reduce)').matches) {
            targetContainer.animate?.([
                { opacity: 0, transform: 'scale(.985)' },
                { opacity: 1, transform: 'scale(1)' }
            ], { duration: 160, easing: 'ease-out' });
        }
        targetContainer.querySelector('[data-fasttag-idle-dock-toggle]')?.addEventListener('click', event => {
            event.preventDefault();
            event.stopPropagation();
            dependencies.setDetachScraper(!detached);
            showAutoScrapeOffState(popup);
        });
        const idleSourceBtn = targetContainer.querySelector?.('#fasttag-scrape-idle-source-btn');
        if (idleSourceBtn) {
            attachSourceDropdown(idleSourceBtn, popup, popup.currentSceneId, async (newSourceId) => {
                if (typeof dependencies?.setActiveScraperSource === 'function') {
                    dependencies.setActiveScraperSource(newSourceId);
                }
                popup._selectedScraperSource = newSourceId;
                refreshIdleSourceBtn(targetContainer, newSourceId);
            });
        }
        refreshIdleSourceBtn(targetContainer, popup._selectedScraperSource);


        if (detached) {
            const header = targetContainer.querySelector('[data-fasttag-auto-scrape-off-header]');
            attachHudDragging(targetContainer, header);
            attachResizeHandles(targetContainer);
        }
        popup._fastTagScraperIdle = true;
        if (popup.scrapeBtn) {
            popup.scrapeBtn.classList.toggle('fasttag-dock-pulse', detached);
            popup.scrapeBtn.innerHTML = dependencies.isEasterEggActive?.() ? '<span>⚡ Scrape 🍫</span>' : '<span>⚡ Scrape</span>';
            popup.scrapeBtn.title = 'Search this scene manually';
        }
        return true;
    }

    function createTrigger(options) {
        if (!dependencies) throw new Error('[FastTag] Scraper controller is not configured');
        const {
            popup,
            mode = 'everything',
            getSceneId,
            getCardElement,
            getContext = () => null,
            focusAfter = () => {}
        } = options || {};
        if (!popup || typeof getSceneId !== 'function') {
            throw new Error('[FastTag] Scraper trigger requires a popup and scene resolver');
        }

        return async (forceOpen = false, targetSceneId = null, targetCardElement = null) => {
            const activeSceneId = targetSceneId || getSceneId();
            const activeCardElement = targetCardElement || getCardElement?.() || null;
            const scrapeRequestId = beginRequest(popup, activeSceneId);
            if (scrapeRequestId == null) return null;

            const idleState = popup._fastTagScraperIdle === true;
            const isScraperOpen = Boolean(
                popup.scraperCardContainer
                && popup.scraperCardContainer.style.display !== 'none'
                && popup.scraperCardContainer.innerHTML.trim() !== ''
            ) || isHudOpen();
            if (isScraperOpen && !forceOpen && !idleState) {
                if (mode === 'everything') {
                    root._fastTagEverythingScraperOpen = false;
                    if (typeof dependencies?.setScraperHudPersistedOpen === 'function') dependencies.setScraperHudPersistedOpen(false);
                    dependencies.log('ACTION', 'SCRAPER', 'Scraper HUD closed by user');
                }
                if (popup.scraperCardContainer) {
                    popup.scraperCardContainer.style.display = 'none';
                    popup.scraperCardContainer.innerHTML = '';
                }
                closeHud();
                popup.scrapeBtn.classList.remove('fasttag-dock-pulse');
                popup.scrapeBtn.innerHTML = dependencies.isEasterEggActive() ? '<span>⚡ Scrape 🍫</span>' : '<span>⚡ Scrape</span>';
                popup.scrapeBtn.title = 'Scrape scene metadata';
                if (mode === 'everything' && popup.refreshBtn) popup.refreshBtn.title = 'Refresh all caches';
                dependencies.hideScrapeCoverTooltip();
                return;
            }
            popup._fastTagScraperIdle = false;

            if (mode === 'everything') {
                root._fastTagEverythingScraperOpen = true;
                dependencies.setScraperHudPersistedOpen(true);
                if (popup.refreshBtn) popup.refreshBtn.title = 'Search again using current scene metadata';
                dependencies.log('ACTION', 'SCRAPER', 'Scraper HUD opened');
            }

            if (sessionCache.has(activeSceneId) && sessionCache.get(activeSceneId)?.length > 0) {
                const cached = sessionCache.get(activeSceneId);
                cached._fromCache = true;
                renderMatches(
                    popup.scraperCardContainer,
                    cached,
                    activeSceneId,
                    getContext(),
                    popup,
                    focusAfter,
                    '',
                    scrapeRequestId
                );
                return;
            }

            const originalHtml = dependencies.isEasterEggActive() ? '<span>⚡ Scrape 🍫</span>' : '<span>⚡ Scrape</span>';
            popup.scrapeBtn.disabled = true;
            popup.scrapeBtn.innerHTML = '<span>⏳ Scraping...</span>';

            const closeLoading = () => {
                invalidateRequests(popup);
                root._fastTagEverythingScraperOpen = false;
                if (typeof dependencies?.setScraperHudPersistedOpen === 'function') dependencies.setScraperHudPersistedOpen(false);
                closeHud();
                if (popup?.scraperCardContainer) {
                    popup.scraperCardContainer.innerHTML = '';
                    popup.scraperCardContainer.style.display = 'none';
                }
                if (popup?.scrapeBtn) {
                    popup.scrapeBtn.disabled = false;
                    popup.scrapeBtn.classList.remove('fasttag-dock-pulse');
                    popup.scrapeBtn.innerHTML = dependencies?.isEasterEggActive?.() ? '<span>⚡ Scrape 🍫</span>' : '<span>⚡ Scrape</span>';
                }
                if (typeof focusAfter === 'function') focusAfter();
            };

            const cancelLoading = () => {
                invalidateRequests(popup);
                if (popup?.scrapeBtn) {
                    popup.scrapeBtn.disabled = false;
                    popup.scrapeBtn.classList.remove('fasttag-dock-pulse');
                    popup.scrapeBtn.innerHTML = dependencies?.isEasterEggActive?.() ? '<span>⚡ Scrape 🍫</span>' : '<span>⚡ Scrape</span>';
                }
                const target = dependencies?.getDetachScraper?.()
                    ? (getHudElement() || popup?.scraperCardContainer)
                    : popup?.scraperCardContainer;
                renderMatches(target, [], activeSceneId, getContext(), popup, focusAfter, '', null);
            };

            const onAbortSearch = async (query) => {
                if (!query) return;
                const abortRequestId = beginRequest(popup, activeSceneId);
                if (abortRequestId == null) return;
                showLoadingState(popup, 'Searching…', onAbortSearch, cancelLoading, closeLoading);
                const abortContainer = dependencies?.getDetachScraper?.()
                    ? (getHudElement() || popup?.scraperCardContainer)
                    : popup?.scraperCardContainer;
                const abortBtn = abortContainer?.querySelector?.('#fasttag-loading-abort-btn');
                const abortInput = abortContainer?.querySelector?.('#fasttag-loading-abort-query');
                if (abortBtn) { abortBtn.disabled = true; abortBtn.textContent = 'Searching…'; }
                if (abortInput) { abortInput.value = query; }
                try {
                    const abortResults = await dependencies.fetchScraperMatchesForScene(
                        activeSceneId, activeCardElement, query,
                        () => isRequestCurrent(popup, activeSceneId, abortRequestId),
                        popup._selectedScraperSource || dependencies.getActiveScraperSource?.() || null
                    );
                    if (!isRequestCurrent(popup, activeSceneId, abortRequestId)) return;
                    if (!abortResults?.length) {
                        dependencies.toastError('No matches found for "' + query + '"');
                        if (abortBtn) { abortBtn.disabled = false; abortBtn.textContent = 'Search'; }
                        if (abortInput) abortInput.focus();
                        return;
                    }
                    sessionCache.set(activeSceneId, abortResults);
                    popup.scrapeBtn.disabled = false;
                    renderMatches(popup.scraperCardContainer, abortResults, activeSceneId, getContext(), popup, focusAfter, '', abortRequestId);
                } catch (err) {
                    if (!isRequestCurrent(popup, activeSceneId, abortRequestId)) return;
                    dependencies.toastError('Search failed: ' + (err?.message || err));
                    if (abortBtn) { abortBtn.disabled = false; abortBtn.textContent = 'Search'; }
                }
            };
            showLoadingState(popup, 'Scraping new scene…', onAbortSearch, cancelLoading, closeLoading);

            try {
                const matches = await dependencies.fetchScraperMatchesForScene(
                    activeSceneId,
                    activeCardElement,
                    '',
                    () => isRequestCurrent(popup, activeSceneId, scrapeRequestId),
                    popup._selectedScraperSource || dependencies.getActiveScraperSource?.() || null
                );
                if (!isRequestCurrent(popup, activeSceneId, scrapeRequestId)) return null;
                if (!matches || matches.length === 0) {
                    if (mode !== 'everything') popup.scrapeBtn.innerHTML = '<span>✕ No Matches</span>';
                    dependencies.toastError('No scraper matches found on configured scrapers');
                    if (mode === 'everything') {
                        const firstPath = popup.sceneData?.files?.[0]?.path || '';
                        const pathParts = firstPath.split(/[/\\]/);
                        const initialSearch = pathParts[pathParts.length - 1] || popup.sceneData?.title || '';
                        await renderMatches(
                            popup.scraperCardContainer,
                            [],
                            activeSceneId,
                            getContext(),
                            popup,
                            focusAfter,
                            initialSearch,
                            scrapeRequestId
                        );
                        return true;
                    }
                    root.setTimeout(() => {
                        if (!isRequestCurrent(popup, activeSceneId, scrapeRequestId)) return;
                        popup.scrapeBtn.disabled = false;
                        popup.scrapeBtn.innerHTML = originalHtml;
                    }, 2500);
                    return;
                }

                sessionCache.set(activeSceneId, matches);
                popup.scrapeBtn.disabled = false;
                renderMatches(
                    popup.scraperCardContainer,
                    matches,
                    activeSceneId,
                    getContext(),
                    popup,
                    focusAfter,
                    '',
                    scrapeRequestId
                );
                return mode === 'everything' ? true : undefined;
            } catch (error) {
                if (!isRequestCurrent(popup, activeSceneId, scrapeRequestId)) return null;
                popup.scrapeBtn.disabled = false;
                popup.scrapeBtn.innerHTML = originalHtml;
                dependencies.toastError('Scrape error: ' + (error?.message || error));
                return mode === 'everything' ? false : undefined;
            }
        };
    }

    async function renderMatches(container, incomingResults, sceneId, ctx, popup, onDismiss, emptySearchQuery = '', scrapeRequestId = null) {
        if (!dependencies) throw new Error('[FastTag] Scraper controller is not configured');
        const document = root.document;
        const {
            entityConfig: ENTITY_CONFIG,
            getScraperMatchingSettings,
            getHideObviousFalsePositives,
            partitionObviousFalsePositiveMatches,
            getDetachScraper,
            getEffectiveTheme,
            getCachedOrNull,
            fetchGQL,
            setCache,
            cleanTitleForScraping,
            isEasterEggActive,
            setScraperHudPersistedOpen,
            fetchScraperMatchesForScene,
            toastError,
            analyzeScraperMatch,
            getScraperResultUrl,
            getPerformerPresentation,
            getAssessmentPresentation,
            getSourcePresentation,
            getUnavailableContextPresentation,
            getAcceptPresentation,
            formatDurationSec,
            escapeHtml,
            setDetachScraper,
            hideScrapeCoverTooltip,
            showScrapeCoverTooltip,
            startScrapedPerformerHover,
            stopScrapedPerformerHover
        } = dependencies;
        if (!isRequestCurrent(popup, sceneId, scrapeRequestId)) {
            if (!isPopupActive(popup) && getHudOwnerPopup() === popup) closeHud();
            return;
        }
        const existingHud = getHudElement();
        if (existingHud?._fastTagIdleSizing) {
            const savedHeight = getHudSize()?.height;
            existingHud._fastTagIdleSizing = false;
            existingHud.style.height = existingHud._fastTagNormalHeight || (typeof savedHeight === 'number' ? `${savedHeight}px` : savedHeight) || '480px';
            delete existingHud._fastTagNormalHeight;
        }
        const initialResultLimit = getScraperMatchingSettings().initialResultLimit;
        const allResults = Array.isArray(incomingResults) ? incomingResults : [];
        const filterFalsePositives = getHideObviousFalsePositives();
        const falsePositivePartition = partitionObviousFalsePositiveMatches(allResults);
        const showingHiddenResults = filterFalsePositives && allResults._fastTagShowHidden === true;
        const filteredResults = filterFalsePositives && !showingHiddenResults
            ? falsePositivePartition.visible
            : allResults;
        const showingAllResults = allResults._fastTagShowAllResults === true;
        const overflowResultCount = Math.max(0, filteredResults.length - initialResultLimit);
        const results = showingAllResults ? filteredResults : filteredResults.slice(0, initialResultLimit);
        const hiddenResultCount = falsePositivePartition.hidden.length;
        const hasResults = results.length > 0;
        const isDetached = getDetachScraper();
        let targetContainer = container;
        let floatingScraperHudElement = getHudElement();
        let floatingScraperHudPosition = getHudPosition();

        if (isDetached) {
            if (popup?.scraperCardContainer) {
                popup.scraperCardContainer.innerHTML = '';
                popup.scraperCardContainer.style.display = 'none';
            }
            floatingScraperHudElement = ensureHud(popup);
            floatingScraperHudPosition = getHudPosition();
            targetContainer = floatingScraperHudElement;
            targetContainer.style.display = 'flex';
        } else {
            closeHud();
            targetContainer = popup?.scraperCardContainer || container;
            if (targetContainer) {
                targetContainer.style.display = 'flex';
            }
        }
        if (!targetContainer) return;

        const popupEl = popup?.element || (targetContainer ? targetContainer.closest('#scenes-popup') : null);
        const restoreSingleSize = () => {};
        const restoreSingleWidth = restoreSingleSize;

        // Ensure caches for performers, studios, tags are available to detect new vs existing entities
        const typesToLoad = [];
        if (!getCachedOrNull('studios')) typesToLoad.push('studios');
        if (!getCachedOrNull('performers')) typesToLoad.push('performers');
        if (!getCachedOrNull('tags')) typesToLoad.push('tags');

        if (typesToLoad.length > 0) {
            await Promise.all(typesToLoad.map(async (type) => {
                try {
                    const list = typeof dependencies?.fetchEntityListSafely === 'function'
                        ? await dependencies.fetchEntityListSafely(type)
                        : ENTITY_CONFIG[type].extractList((await fetchGQL(ENTITY_CONFIG[type].fetchQuery))?.data);
                    if (list) setCache(type, list);
                } catch (e) {
                    console.log('[FastTag] Error pre-caching ' + type, e);
                }
            }));
        }

        // Cache loading and scraper requests can finish after the owning popup closes.
        // Do not let a stale continuation recreate or update a detached HUD.
        if (!isRequestCurrent(popup, sceneId, scrapeRequestId)) {
            if (!isPopupActive(popup) && getHudOwnerPopup() === popup) closeHud();
            return;
        }

        let currentIndex = 0;
        const isDark = getEffectiveTheme() === 'dark';
        const availableSources = typeof dependencies.loadScraperSources === 'function'
            ? await dependencies.loadScraperSources()
            : { stashBoxes: [], scrapers: [], all: [] };
        const activeSource = typeof dependencies.resolveActiveSource === 'function'
            ? dependencies.resolveActiveSource(availableSources, popup?._selectedScraperSource || dependencies?.getActiveScraperSource?.() || null)
            : { id: 'stashbox_0', name: 'StashDB.org', shortName: 'StashDB' };

        const handleSourceChange = async (newSourceId) => {
            if (typeof dependencies?.setActiveScraperSource === 'function') {
                dependencies.setActiveScraperSource(newSourceId);
            }
            popup._selectedScraperSource = newSourceId;
            const newRequestId = beginRequest(popup, sceneId);
            if (newRequestId == null) return;

            const closeSourceLoading = () => {
                invalidateRequests(popup);
                root._fastTagEverythingScraperOpen = false;
                if (typeof dependencies?.setScraperHudPersistedOpen === 'function') dependencies.setScraperHudPersistedOpen(false);
                closeHud();
                if (container) {
                    container.innerHTML = '';
                    container.style.display = 'none';
                }
                if (popup?.scrapeBtn) {
                    popup.scrapeBtn.disabled = false;
                    popup.scrapeBtn.classList.remove('fasttag-dock-pulse');
                    popup.scrapeBtn.innerHTML = dependencies?.isEasterEggActive?.() ? '<span>⚡ Scrape 🍫</span>' : '<span>⚡ Scrape</span>';
                }
                if (typeof onDismiss === 'function') onDismiss();
            };

            const cancelSourceLoading = () => {
                invalidateRequests(popup);
                if (popup?.scrapeBtn) {
                    popup.scrapeBtn.disabled = false;
                    popup.scrapeBtn.classList.remove('fasttag-dock-pulse');
                    popup.scrapeBtn.innerHTML = dependencies?.isEasterEggActive?.() ? '<span>⚡ Scrape 🍫</span>' : '<span>⚡ Scrape</span>';
                }
                renderMatches(container, [], sceneId, ctx, popup, onDismiss, '', null);
            };

            const onSourceAbortSearch = async (query) => {
                if (!query) return;
                const abortReqId = beginRequest(popup, sceneId);
                if (abortReqId == null) return;
                showLoadingState(popup, 'Searching…', onSourceAbortSearch, cancelSourceLoading, closeSourceLoading);
                const abortContainer = dependencies?.getDetachScraper?.()
                    ? (getHudElement() || popup?.scraperCardContainer)
                    : popup?.scraperCardContainer;
                const abortBtn = abortContainer?.querySelector?.('#fasttag-loading-abort-btn');
                const abortInput = abortContainer?.querySelector?.('#fasttag-loading-abort-query');
                if (abortBtn) { abortBtn.disabled = true; abortBtn.textContent = 'Searching…'; }
                if (abortInput) { abortInput.value = query; }
                try {
                    const abortResults = await (dependencies.fetchScraperMatchesForScene || fetchScraperMatchesForScene)(
                        sceneId,
                        null,
                        query,
                        () => isRequestCurrent(popup, sceneId, abortReqId),
                        newSourceId
                    );
                    if (!isRequestCurrent(popup, sceneId, abortReqId)) return;
                    if (!abortResults?.length) {
                        toastError('No matches found for "' + query + '"');
                        await renderMatches(container, [], sceneId, ctx, popup, onDismiss, query, abortReqId);
                        return;
                    }
                    sessionCache.set(sceneId, abortResults);
                    hideScrapeCoverTooltip();
                    await renderMatches(container, abortResults, sceneId, ctx, popup, onDismiss, '', abortReqId);
                } catch (err) {
                    if (!isRequestCurrent(popup, sceneId, abortReqId)) return;
                    toastError('Search failed: ' + (err?.message || err));
                    await renderMatches(container, [], sceneId, ctx, popup, onDismiss, query, abortReqId);
                }
            };

            showLoadingState(popup, 'Scraping new scene…', onSourceAbortSearch, cancelSourceLoading, closeSourceLoading);
            try {
                const newResults = await (dependencies.fetchScraperMatchesForScene || fetchScraperMatchesForScene)(
                    sceneId,
                    null,
                    '',
                    () => isRequestCurrent(popup, sceneId, newRequestId),
                    newSourceId
                );
                if (!isRequestCurrent(popup, sceneId, newRequestId)) return;
                sessionCache.set(sceneId, newResults);
                hideScrapeCoverTooltip();
                await renderMatches(container, newResults, sceneId, ctx, popup, onDismiss, '', newRequestId);
            } catch (error) {
                if (!isRequestCurrent(popup, sceneId, newRequestId)) return;
                toastError('Scrape failed: ' + (error?.message || error));
                await renderMatches(container, [], sceneId, ctx, popup, onDismiss, '', newRequestId);
            }
        };

        if (!hasResults) {
            let initialQuery = cleanTitleForScraping(emptySearchQuery || '');
            if (!initialQuery && popup) {
                const titleCandidate = popup._context?.activeScene?.title
                    || popup.element?.querySelector?.('.title, .card-title, .scene-card__title')?.textContent
                    || '';
                if (titleCandidate) initialQuery = cleanTitleForScraping(titleCandidate);
            }
            targetContainer.innerHTML = `
                <div style="display: flex; flex-direction: column; gap: 10px; padding: 12px; box-sizing: border-box; height: 100%; min-height: 150px;">
                    <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px;">
                        <div style="display: flex; align-items: center; gap: 6px;">
                        <strong style="font-size: 12px; color: ${isDark ? '#e2e8f0' : '#1e293b'};">${activeSource?.isUrlOnly ? '🔗' : '⚡'} Scraper</strong>
                        <button type="button" id="fasttag-scrape-empty-source-btn" class="fasttag-source-selector-btn" style="background: ${isDark ? 'rgba(99, 102, 241, 0.22)' : 'rgba(99, 102, 241, 0.12)'}; border: 1px solid ${isDark ? 'rgba(129, 140, 248, 0.5)' : '#818cf8'}; border-radius: 5px; color: ${isDark ? '#e0e7ff' : '#312e81'}; font-size: 10.5px; font-weight: 700; padding: 1.5px 6px; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; max-width: 140px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; line-height: 1.3;" title="Active Scraper: ${escapeHtml(activeSource?.name || 'StashDB')} (Click to switch)">
                            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 90px;">${escapeHtml(activeSource?.shortName || activeSource?.name || 'StashDB')}</span>
                            ${activeSource?.isUrlOnly ? '<span style="font-size: 8px; color: #38bdf8; font-weight: 800;">[URL]</span>' : ''}
                            <span style="font-size: 8px; opacity: 0.7; transform: translateY(0.5px);">▼</span>
                        </button>
                    </div>
                        <button type="button" id="fasttag-scrape-empty-close" style="border: none; background: transparent; color: ${isDark ? '#94a3b8' : '#64748b'}; font-size: 15px; cursor: pointer;">✕</button>
                    </div>
                    <div style="padding: 8px; border-radius: 6px; background: ${activeSource?.isUrlOnly ? (isDark ? 'rgba(56, 189, 248, 0.1)' : '#f0f9ff') : (isDark ? 'rgba(245,158,11,0.1)' : '#fffbeb')}; border: 1px solid ${activeSource?.isUrlOnly ? (isDark ? 'rgba(56, 189, 248, 0.35)' : '#7dd3fc') : (isDark ? 'rgba(245,158,11,0.35)' : '#fcd34d')}; color: ${activeSource?.isUrlOnly ? (isDark ? '#bae6fd' : '#0369a1') : (isDark ? '#fde68a' : '#92400e')}; font-size: 11px;">
                        ${activeSource?.isUrlOnly ? '🔗 <strong>URL-only scraper:</strong> This studio scraper requires a direct video link. Paste the URL below to scrape it.' : 'No automatic matches were found. Edit the search words below and try again.'}
                    </div>
                    <div style="display: flex; align-items: center; gap: 6px;">
                        <input id="fasttag-scrape-empty-query" type="text" value="${escapeHtml(initialQuery)}" placeholder="${activeSource?.isUrlOnly ? 'Paste video URL to scrape (https://...)' : 'Enter title, studio or performer names, or paste URL'}" style="flex: 1; min-width: 0; height: 30px; box-sizing: border-box; padding: 4px 8px; border-radius: 6px; border: 1px solid ${isDark ? 'rgba(129,140,248,0.55)' : '#a5b4fc'}; background: ${isDark ? '#0f172a' : '#ffffff'}; color: ${isDark ? '#e2e8f0' : '#1e293b'}; font-size: 11px; outline: none;">
                        <button id="fasttag-scrape-empty-search" type="button" style="height: 30px; padding: 4px 10px; border-radius: 6px; border: 1px solid rgba(129,140,248,0.6); background: rgba(99,102,241,0.22); color: ${isDark ? '#c7d2fe' : '#4338ca'}; font-size: 10.5px; font-weight: 700; cursor: pointer;">Search</button>
                    </div>
                </div>
            `;

            const closeEmpty = () => {
                invalidateRequests(popup);
                root._fastTagEverythingScraperOpen = false;
                if (typeof dependencies?.setScraperHudPersistedOpen === 'function') dependencies.setScraperHudPersistedOpen(false);
                closeHud();
                if (container) {
                    container.innerHTML = '';
                    container.style.display = 'none';
                }
                if (popup?.scrapeBtn) {
                    popup.scrapeBtn.disabled = false;
                    popup.scrapeBtn.classList.remove('fasttag-dock-pulse');
                    popup.scrapeBtn.innerHTML = isEasterEggActive() ? '<span>⚡ Scrape 🍫</span>' : '<span>⚡ Scrape</span>';
                }
                if (typeof onDismiss === 'function') onDismiss();
            };
            const runEmptySearch = async () => {
                const input = targetContainer.querySelector('#fasttag-scrape-empty-query');
                const button = targetContainer.querySelector('#fasttag-scrape-empty-search');
                const query = (input?.value || '').trim();
                if (!query) {
                    toastError('Enter the words you want to search for.');
                    input?.focus();
                    return;
                }
                const manualRequestId = beginRequest(popup, sceneId);
                if (manualRequestId == null) return;
                button.disabled = true;
                button.textContent = 'Searching…';
                try {
                    const manualResults = await fetchScraperMatchesForScene(
                        sceneId,
                        null,
                        query,
                        () => isRequestCurrent(popup, sceneId, manualRequestId),
                        popup?._selectedScraperSource || dependencies?.getActiveScraperSource?.() || activeSource?.id
                    );
                    if (!isRequestCurrent(popup, sceneId, manualRequestId)) return;
                    if (!manualResults?.length) {
                        toastError(`No scraper matches found for “${query}”`);
                        button.disabled = false;
                        button.textContent = 'Search';
                        input?.focus();
                        return;
                    }
                    sessionCache.set(sceneId, manualResults);
                    await renderMatches(container, manualResults, sceneId, ctx, popup, onDismiss, '', manualRequestId);
                } catch (error) {
                    if (!isRequestCurrent(popup, sceneId, manualRequestId)) return;
                    button.disabled = false;
                    button.textContent = 'Search';
                    toastError('Scrape search failed: ' + (error?.message || error));
                }
            };

            targetContainer.querySelector('#fasttag-scrape-empty-close')?.addEventListener('click', closeEmpty);
            const emptySearchInput = targetContainer.querySelector('#fasttag-scrape-empty-query');
            emptySearchInput?.addEventListener('keydown', (event) => {
                if (event.key !== 'Enter') return;
                event.preventDefault();
                event.stopPropagation();
                runEmptySearch();
            });
            targetContainer.querySelector('#fasttag-scrape-empty-search')?.addEventListener('click', runEmptySearch);
            if (popup?.scrapeBtn) {
                popup.scrapeBtn.disabled = false;
                popup.scrapeBtn.innerHTML = isEasterEggActive() ? '<span>▲ Hide 🍫</span>' : '<span>▲ Hide</span>';
                if (isDetached) popup.scrapeBtn.classList.add('fasttag-dock-pulse');
            }
            if (isDetached && floatingScraperHudElement) attachResizeHandles(floatingScraperHudElement);
            const emptySourceBtn = targetContainer.querySelector("#fasttag-scrape-empty-source-btn");
            if (emptySourceBtn) attachSourceDropdown(emptySourceBtn, popup, sceneId, handleSourceChange);
            const activeEl = root.document?.activeElement;
            const isUserInScraperInput = targetContainer && typeof targetContainer.contains === "function" && targetContainer.contains(activeEl) && (activeEl.tagName === "INPUT" || activeEl.tagName === "TEXTAREA");
            if (!isUserInScraperInput) {
                const mainSearch = popup?.globalSearch || popup?.searchInput || popup?.element?.querySelector?.("#everything-global-search, input[type=\"text\"], input[type=\"search\"]");
                if (mainSearch && root.document?.body?.contains(mainSearch)) {
                    mainSearch.focus({ preventScroll: true });
                }
            }
            return;
        }

        const updateCardView = () => {
            const match = results[currentIndex];
            if (!match) return;

            const studioName = match.studio?.name || '';
            const performers = match.performers || [];
            const tags = match.tags || [];
            const urls = match.urls || [];

            const cachedStudios = getCachedOrNull('studios') || [];
            const cachedPerformers = getCachedOrNull('performers') || [];
            const cachedTags = getCachedOrNull('tags') || [];

            const isStudioNew = studioName ? !(match.studio?.stored_id || cachedStudios.some(s => (s.name || '').trim().toLowerCase() === studioName.trim().toLowerCase())) : false;

            const remoteResultUrl = getScraperResultUrl(match);

            // Calculate match likelihood & fingerprint verification (mirroring Stash's native scraper)
            const {
                isHashMatch,
                matchBadges,
                localDurSec,
                scrapedDurSec,
                totalFps,
                matchingDurFps
            } = analyzeScraperMatch(match);

            const performerPresentation = getPerformerPresentation(match);
            let performerMatchBadge = '';
            if (performerPresentation) {
                const overlapNames = performerPresentation.overlapNames;
                if (overlapNames.length > 0) {
                    performerMatchBadge = `
                        <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 600; color: #34d399; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.35); padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="Matches performer already linked to this scene: ${escapeHtml(overlapNames.join(', '))}">
                            <span>★</span><span>Performer Match (${performerPresentation.overlapCount}/${performerPresentation.linkedCount})</span>
                        </span>
                    `;
                } else if (performerPresentation.performerSetConflict) {
                    performerMatchBadge = `
                        <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 600; color: #f87171; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.4); padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="The returned performer set is completely different from the performers linked to this scene.">
                            <span>⚠</span><span>Performer Set Conflict</span>
                        </span>
                    `;
                } else if (performerPresentation.hasWeakOverlap) {
                    performerMatchBadge = `
                        <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 600; color: #fbbf24; background: rgba(245, 158, 11, 0.15); border: 1px solid rgba(245, 158, 11, 0.4); padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="A returned single-word name could be an alias of ${escapeHtml(performerPresentation.weakOverlapNames.join(', '))}, but it is too ambiguous to confirm a performer match.">
                            <span>?</span><span>Possible Alias Match</span>
                        </span>
                    `;
                } else {
                    performerMatchBadge = `
                        <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 600; color: #fbbf24; background: rgba(245, 158, 11, 0.15); border: 1px solid rgba(245, 158, 11, 0.4); padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="None of this result's performers match the ${performerPresentation.linkedCount} performer(s) already linked to your scene. Check the result carefully before accepting it.">
                            <span>⚠</span><span>No Linked Performer Match</span>
                        </span>
                    `;
                }
            }

            const assessment = getAssessmentPresentation(match);
            const assessmentBadge = assessment ? `
                <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 700; color: ${assessment.color}; background: ${assessment.background}; border: 1px solid ${assessment.border}; padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="${escapeHtml(assessment.tooltip)}">
                    <span>${assessment.icon}</span><span>${assessment.label}</span>
                </span>
            ` : '';

            const sourcePresentation = getSourcePresentation(match, isHashMatch);
            const sourceTone = sourcePresentation?.tone === 'success'
                ? { color: '#34d399', background: 'rgba(16, 185, 129, 0.15)', border: 'rgba(16, 185, 129, 0.35)', icon: '✓' }
                : sourcePresentation?.tone === 'warning'
                    ? { color: '#fbbf24', background: 'rgba(245, 158, 11, 0.15)', border: 'rgba(245, 158, 11, 0.4)', icon: '⌕' }
                    : { color: isDark ? '#cbd5e1' : '#475569', background: 'rgba(148, 163, 184, 0.12)', border: 'rgba(148, 163, 184, 0.3)', icon: '↗' };
            const sourceBadge = sourcePresentation ? `
                <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 600; color: ${sourceTone.color}; background: ${sourceTone.background}; border: 1px solid ${sourceTone.border}; padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="${escapeHtml(sourcePresentation.tooltip)}">
                    <span>${sourceTone.icon}</span><span>${escapeHtml(sourcePresentation.label)}</span>
                </span>
            ` : '';

            const unavailableContext = getUnavailableContextPresentation(match);
            const unavailableContextBadge = unavailableContext ? `
                <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 500; color: ${isDark ? '#94a3b8' : '#64748b'}; background: rgba(148, 163, 184, 0.1); border: 1px dashed rgba(148, 163, 184, 0.4); padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="${escapeHtml(unavailableContext.tooltip)}">
                    <span>ⓘ</span><span>${escapeHtml(unavailableContext.label)}</span>
                </span>
            ` : '';

            const studioMismatchBadge = match._studioComparison === 'mismatch' ? `
                <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 600; color: #f87171; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.35); padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="The scraped studio (${escapeHtml(studioName)}) differs from the studio already linked to this scene.">
                    <span>⚠</span><span>Studio Mismatch</span>
                </span>
            ` : '';
            const additionalPerformerBadge = performerPresentation?.additionalCount > 0 ? `
                <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 600; color: #fbbf24; background: rgba(245, 158, 11, 0.15); border: 1px solid rgba(245, 158, 11, 0.4); padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="The scraped result contains additional performer(s) not currently linked to this scene: ${escapeHtml(performerPresentation.additionalNames.join(', '))}">
                    <span>＋</span><span>${performerPresentation.additionalCount} Additional Performer${performerPresentation.additionalCount === 1 ? '' : 's'}</span>
                </span>
            ` : '';
            const acceptPresentation = getAcceptPresentation(match);

            let durationBadge = '';
            if (scrapedDurSec && localDurSec) {
                const diff = Math.abs(scrapedDurSec - localDurSec);
                if (diff <= 3) {
                    durationBadge = `
                        <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 600; color: #34d399; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.35); padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="Duration matches within 3 seconds (${formatDurationSec(scrapedDurSec)})">
                            <span>⏱</span><span>${formatDurationSec(scrapedDurSec)} (Exact Match)</span>
                        </span>
                    `;
                } else if (diff <= 60) {
                    durationBadge = `
                        <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 500; color: ${isDark ? '#cbd5e1' : '#475569'}; background: rgba(148, 163, 184, 0.12); border: 1px solid rgba(148, 163, 184, 0.25); padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="Scraped duration is ${formatDurationSec(scrapedDurSec)}, local is ${formatDurationSec(localDurSec)}">
                            <span>⏱</span><span>${formatDurationSec(scrapedDurSec)} (Local: ${formatDurationSec(localDurSec)})</span>
                        </span>
                    `;
                } else {
                    durationBadge = `
                        <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 600; color: #f87171; background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.35); padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="Scraped duration is ${formatDurationSec(scrapedDurSec)}, local is ${formatDurationSec(localDurSec)}; the difference is ${formatDurationSec(diff)}.">
                            <span>⚠</span><span>Duration Mismatch (${formatDurationSec(diff)})</span>
                        </span>
                    `;
                }
            } else if (localDurSec) {
                if (matchingDurFps > 0) {
                    durationBadge = `
                        <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 600; color: #34d399; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.35); padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="${matchingDurFps} of ${totalFps} StashDB submissions match your duration (${formatDurationSec(localDurSec)})">
                            <span>⏱</span><span>${formatDurationSec(localDurSec)} (${matchingDurFps}/${totalFps} Match)</span>
                        </span>
                    `;
                } else {
                    durationBadge = `
                        <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 500; color: ${isDark ? '#94a3b8' : '#64748b'}; background: rgba(148, 163, 184, 0.12); border: 1px solid rgba(148, 163, 184, 0.25); padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;">
                            <span>⏱</span><span>${formatDurationSec(localDurSec)}</span>
                        </span>
                    `;
                }
            }

            const scraperSourceName = String(match._sourceName || 'StashDB').trim() || 'StashDB';
            const scraperSourceLabel = scraperSourceName.replace(/\.(?:org|com|net|cc)$/i, '');

            let savedEmbeddedH = 220;
            try {
                const h = parseInt(root.localStorage.getItem('fasttag_embedded_scraper_h'), 10);
                if (!isNaN(h) && h >= 50 && h <= 520) savedEmbeddedH = h;
            } catch (e) {}

            targetContainer.style.display = isDetached ? 'flex' : 'flex';
            targetContainer.innerHTML = `
                <div style="background: ${isDark ? 'rgba(15, 23, 42, 0.95)' : '#f8fafc'}; border: ${isDetached ? 'none' : (isDark ? '1px solid rgba(99, 102, 241, 0.5)' : '1px solid #818cf8')}; border-radius: 8px; box-shadow: ${isDetached ? 'none' : '0 10px 25px rgba(0,0,0,0.5)'}, inset 0 0 0 1px rgba(255,255,255,0.06); padding: 9px 12px 6px 12px; box-sizing: border-box; display: flex; flex-direction: column; gap: 7px; ${isDetached ? 'height: 100%; min-height: 0; flex: 1 1 auto;' : 'height: auto;'} font-family: system-ui, -apple-system, sans-serif; transition: all 0.2s ease;">
                    <!-- Top Navigation & Link Header -->
                    <div id="fasttag-scrape-header" style="display: flex; flex-direction: row; align-items: center; justify-content: space-between; gap: 4px 6px; flex-wrap: nowrap; user-select: none; white-space: nowrap; overflow: visible; min-height: 26px; padding: 1px 0;">
                        <div id="fasttag-scrape-header-primary" style="display: flex; align-items: center; gap: 6px; font-size: 11.5px; font-weight: 700; color: ${isDark ? '#e0e7ff' : '#312e81'}; min-width: 0; flex: 1 1 150px; overflow: hidden;">
                            <span style="font-size: 13px; line-height: 1; flex-shrink: 0;">⚡</span>
                            <button type="button" id="fasttag-scrape-source-btn" class="fasttag-source-selector-btn" style="background: ${isDark ? 'rgba(99, 102, 241, 0.22)' : 'rgba(99, 102, 241, 0.12)'}; border: 1px solid ${isDark ? 'rgba(129, 140, 248, 0.5)' : '#818cf8'}; border-radius: 5px; color: ${isDark ? '#e0e7ff' : '#312e81'}; font-size: 11px; font-weight: 700; padding: 1.5px 6px; cursor: pointer; display: inline-flex; align-items: center; gap: 3px; max-width: 130px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; line-height: 1.3; transition: all 0.15s ease;" title="Active Scraper: ${escapeHtml(activeSource?.name || scraperSourceName)} (Click to switch)">
                                <span id="fasttag-scrape-source-label" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 95px;" title="${escapeHtml(scraperSourceName)}">${escapeHtml(scraperSourceLabel)}</span>
                                <span style="font-size: 8px; opacity: 0.7; transform: translateY(0.5px);">▼</span>
                            </button>
                            ${results.length > 1 ? `
                                <div id="fasttag-scrape-match-counter" class="fasttag-match-counter-pulse" style="display: inline-flex; align-items: center; justify-content: center; gap: 4px; width: 92px; box-sizing: border-box; font-size: 11px; font-weight: 700; color: ${isDark ? '#e0e7ff' : '#312e81'}; background: ${isDark ? 'rgba(99, 102, 241, 0.25)' : 'rgba(99, 102, 241, 0.12)'}; border: 1px solid ${isDark ? 'rgba(129, 140, 248, 0.75)' : '#818cf8'}; padding: 2px 5px; border-radius: 5px; margin-left: 2px; user-select: none; flex: 0 0 92px; white-space: nowrap; line-height: 1;">
                                    <button type="button" id="fasttag-scrape-prev" style="background: rgba(255,255,255,0.1); border: 1px solid rgba(148,163,184,0.4); border-radius: 3px; cursor: pointer; color: inherit; padding: 1px 5px; font-size: 9.5px; line-height: 1; transition: all 0.15s ease;" ${currentIndex === 0 ? 'disabled style="opacity: 0.3; cursor: not-allowed;"' : ''} title="Previous match (Left Arrow)">◀</button>
                                    <span style="min-width: 29px; text-align: center; font-variant-numeric: tabular-nums; letter-spacing: 0.2px; font-size: 11px; font-weight: 700; white-space: nowrap;">${currentIndex + 1}/${results.length}</span>
                                    <button type="button" id="fasttag-scrape-next" style="background: rgba(255,255,255,0.1); border: 1px solid rgba(148,163,184,0.4); border-radius: 3px; cursor: pointer; color: inherit; padding: 1px 5px; font-size: 9.5px; line-height: 1; transition: all 0.15s ease;" ${currentIndex === results.length - 1 ? 'disabled style="opacity: 0.3; cursor: not-allowed;"' : ''} title="Next match (Right Arrow)">▶</button>
                                </div>
                            ` : ''}
                        </div>
                        <div id="fasttag-scrape-header-actions" style="display: flex; align-items: center; gap: 4px; flex-shrink: 0; max-width: 100%; margin-left: auto; white-space: nowrap;">
                            ${remoteResultUrl ? `
                                <a href="${remoteResultUrl}" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; gap: 2px; font-size: 10px; font-weight: 600; color: #818cf8; text-decoration: none; padding: 2.5px 6px; border-radius: 4px; background: rgba(99, 102, 241, 0.15); border: 1px solid rgba(99, 102, 241, 0.4); transition: background 0.15s ease; white-space: nowrap; line-height: 1;" title="Open in ${escapeHtml(match._sourceName || 'source')} in new tab">
                                    <span>🔗</span><span>↗</span>
                                </a>
                            ` : ''}
                            <button type="button" id="fasttag-scrape-popout-toggle" style="background: rgba(99, 102, 241, 0.15); border: 1px solid rgba(99, 102, 241, 0.4); border-radius: 4px; padding: 2.5px 6px; font-size: 10px; font-weight: 700; color: #818cf8; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 3px; line-height: 1; transition: all 0.15s ease; white-space: nowrap;" data-micro-tooltip="${isDetached ? 'Dock scraper inside popup' : 'Pop out scraper into floating window'}">
                                <svg viewBox="0 0 24 24" width="10" height="10" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: block; pointer-events: none;">
                                    <rect x="2" y="4" width="20" height="16" rx="2" stroke="currentColor" fill="none" stroke-width="2"></rect>
                                    <rect x="12" y="11" width="8" height="7" rx="1.5" fill="currentColor" stroke="none"></rect>
                                </svg>
                                <span id="fasttag-scrape-dock-label">${isDetached ? 'Dock' : 'Pop Out'}</span>
                            </button>
                            <button type="button" id="fasttag-scrape-accept-btn" style="background: ${acceptPresentation.background}; border: 1px solid ${acceptPresentation.border}; color: #ffffff; padding: 2.5px 7px; border-radius: 4px; font-size: 10px; cursor: pointer; font-weight: 700; display: inline-flex; align-items: center; gap: 2px; box-shadow: 0 1px 4px ${acceptPresentation.shadow}; line-height: 1.2; transition: all 0.15s ease; white-space: nowrap; flex-shrink: 0;" title="${acceptPresentation.title}">
                                <span>${acceptPresentation.label}</span>
                            </button>
                        </div>
                    </div>

                    <div id="fasttag-scrape-manual-search-form" style="display: flex; align-items: center; gap: 5px;">
                        <input id="fasttag-scrape-manual-query" type="text" value="${escapeHtml(match._searchQuery || '')}" placeholder="Optional: correct the search words" style="flex: 1; min-width: 0; height: 25px; box-sizing: border-box; padding: 3px 7px; border-radius: 5px; border: 1px solid ${isDark ? 'rgba(129,140,248,0.45)' : '#a5b4fc'}; background: ${isDark ? 'rgba(15,23,42,0.8)' : '#ffffff'}; color: ${isDark ? '#e2e8f0' : '#1e293b'}; font-size: 10.5px; outline: none;">
                        <button id="fasttag-scrape-manual-search-btn" type="button" style="height: 25px; padding: 3px 8px; border-radius: 5px; border: 1px solid rgba(129,140,248,0.55); background: rgba(99,102,241,0.18); color: ${isDark ? '#c7d2fe' : '#4338ca'}; font-size: 10px; font-weight: 700; cursor: pointer; white-space: nowrap;">Search</button>
                    </div>

                    ${filterFalsePositives && hiddenResultCount > 0 ? `
                        <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 3px 6px; border-radius: 5px; background: rgba(245,158,11,0.09); border: 1px solid rgba(245,158,11,0.25); color: ${isDark ? '#fcd34d' : '#92400e'}; font-size: 9.5px; line-height: 1.25;">
                            <span>${hiddenResultCount} obvious false positive${hiddenResultCount === 1 ? '' : 's'} ${showingHiddenResults ? 'shown' : 'hidden'}</span>
                            <button id="fasttag-scrape-toggle-hidden" type="button" style="border: 1px solid rgba(245,158,11,0.45); border-radius: 4px; background: rgba(245,158,11,0.12); color: inherit; padding: 2px 6px; font-size: 9.5px; font-weight: 700; cursor: pointer; white-space: nowrap;">${showingHiddenResults ? 'Hide again' : 'Show hidden'}</button>
                        </div>
                    ` : ''}

                    ${overflowResultCount > 0 ? `
                        <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 3px 6px; border-radius: 5px; background: rgba(99,102,241,0.09); border: 1px solid rgba(129,140,248,0.25); color: ${isDark ? '#c7d2fe' : '#3730a3'}; font-size: 9.5px; line-height: 1.25;">
                            <span>${overflowResultCount} lower-ranked result${overflowResultCount === 1 ? '' : 's'} ${showingAllResults ? 'shown' : 'not shown initially'}</span>
                            <button id="fasttag-scrape-toggle-overflow" type="button" style="border: 1px solid rgba(129,140,248,0.45); border-radius: 4px; background: rgba(99,102,241,0.12); color: inherit; padding: 2px 6px; font-size: 9.5px; font-weight: 700; cursor: pointer; white-space: nowrap;">${showingAllResults ? 'Show top 25' : 'Show all'}</button>
                        </div>
                    ` : ''}

                    <div id="fasttag-scrape-body-wrapper" style="display: flex; flex-direction: column; gap: 7px; ${isDetached ? 'flex: 1 1 auto; min-height: 0; overflow: hidden;' : 'height: auto;'} transition: all 0.15s ease;">
                        <!-- Dedicated Verification Badges Row -->
                        <div style="display: flex; align-items: center; gap: 5px; flex-wrap: wrap; padding: 3px 6px; background: ${isDark ? 'rgba(0,0,0,0.22)' : 'rgba(0,0,0,0.03)'}; border-radius: 5px; border: 1px solid ${isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)'}; flex-shrink: 0;">
                            ${assessmentBadge}
                            ${sourceBadge}
                            ${isHashMatch ? matchBadges.map(b => `
                                <span style="display: inline-flex; align-items: center; gap: 3px; font-size: 9.5px; font-weight: 600; color: #34d399; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.35); padding: 1px 5px; border-radius: 4px; cursor: help; user-select: none;" data-micro-tooltip="Direct file fingerprint match on StashDB">
                                    <span>✓</span><span>${b}</span>
                                </span>
                            `).join('') : ''}
                            ${unavailableContextBadge}
                            ${performerMatchBadge}
                            ${additionalPerformerBadge}
                            ${studioMismatchBadge}
                            ${durationBadge}
                            <button type="button" id="fasttag-scrape-dismiss-match" style="margin-left: auto; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(248, 113, 113, 0.32); border-radius: 4px; padding: 2px 6px; font-size: 9.5px; font-weight: 700; color: #f87171; cursor: pointer; line-height: 1.2; white-space: nowrap;" title="Remove this result from the current FastTag session">✕ Dismiss</button>
                        </div>

                    <!-- Items Preview Box with Relative Wrapper for Scroll Indicator -->
                    <div style="position: relative; border-radius: 6px; overflow: hidden; ${isDetached ? 'flex: 1 1 auto; min-height: 0; display: flex; flex-direction: column;' : 'height: auto;'}">
                        <div id="fasttag-scrape-items-preview" style="display: flex; flex-direction: column; gap: 7px; background: ${isDark ? 'rgba(0,0,0,0.25)' : 'rgba(0,0,0,0.03)'}; padding: 7px 9px 10px 9px; border-radius: 6px; font-size: 11px; box-sizing: border-box; overflow-y: auto; overflow-x: hidden; ${isDetached ? 'flex: 1 1 auto; min-height: 80px; max-height: none;' : `height: ${savedEmbeddedH}px; min-height: 50px; max-height: 520px;`} scrollbar-width: thin; scrollbar-color: ${isDark ? 'rgba(129, 140, 248, 0.65) rgba(0,0,0,0.25)' : '#a5b4fc #f1f5f9'}; transition: opacity 0.1s ease;">
                            ${isDetached ? `
                                <!-- Detached Hero Cover Banner (On its own dedicated line) -->
                                ${match.image ? `
                                    <div class="fasttag-scrape-cover-thumb" style="width: 100%; max-height: clamp(160px, 35vh, 320px); aspect-ratio: 16/9; border-radius: 6px; overflow: hidden; background: #000; border: 1px solid ${isDark ? 'rgba(255,255,255,0.18)' : '#cbd5e1'}; display: flex; align-items: center; justify-content: center; cursor: pointer; position: relative; transition: all 0.15s ease; box-shadow: 0 4px 12px rgba(0,0,0,0.3); flex-shrink: 0;" title="Hover to view full-size cover">
                                        <img src="${match.image}" alt="Cover" style="width: 100%; height: 100%; object-fit: cover; display: block;" loading="lazy" />
                                        <label style="position: absolute; left: 7px; bottom: 7px; z-index: 2; display: inline-flex; align-items: center; gap: 4px; padding: 3px 7px; border-radius: 4px; background: rgba(15, 23, 42, 0.88); color: #e0e7ff; font-size: 10px; font-weight: 700; cursor: pointer; user-select: none;" title="Include this cover image when accepting the match">
                                            <input type="checkbox" id="fasttag-scrape-chk-cover" checked style="cursor: pointer; width: 11px; height: 11px; accent-color: #6366f1; margin: 0;">
                                            <span>🖼️ Cover</span>
                                        </label>
                                    </div>
                                ` : ''}

                                <!-- Title & Studio (Clean stacked rows directly below hero cover) -->
                                <div style="display: flex; flex-direction: column; gap: 6px;">
                                    <!-- Title Row -->
                                    <div style="display: flex; align-items: baseline; gap: 6px; flex-wrap: wrap;">
                                        <label style="display: inline-flex; align-items: baseline; gap: 4px; min-width: 55px; flex-shrink: 0; cursor: pointer; user-select: none; font-weight: 600; color: ${isDark ? '#e0e7ff' : '#312e81'}; font-size: 11px;" title="Check to update scene title">
                                            <input type="checkbox" id="fasttag-scrape-chk-title" style="cursor: pointer; width: 12px; height: 12px; accent-color: #6366f1; margin: 0; position: relative; top: 1.5px;">
                                            <span style="font-size: 11px;">✏️</span>
                                            <span>Title:</span>
                                        </label>
                                        <span style="display: inline-block; max-width: calc(100% - 75px); background: ${isDark ? 'rgba(99, 102, 241, 0.2)' : '#e0e7ff'}; color: ${isDark ? '#e0e7ff' : '#312e81'}; padding: 2px 7px; border-radius: 4px; font-weight: 700; font-size: 11px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; vertical-align: middle;" title="${escapeHtml(match.title || '')}">${escapeHtml(match.title || 'Untitled Match')}</span>
                                        ${match.date ? `
                                            <label style="display: inline-flex; align-items: baseline; gap: 4px; font-size: 10.5px; color: ${isDark ? '#94a3b8' : '#64748b'}; font-weight: 500; cursor: pointer; user-select: none;" title="Include this date when accepting the match">
                                                <input type="checkbox" id="fasttag-scrape-chk-date" checked style="cursor: pointer; width: 11px; height: 11px; accent-color: #0ea5e9; margin: 0; position: relative; top: 1px;">
                                                <span>📅 ${escapeHtml(match.date)}</span>
                                            </label>
                                        ` : ''}
                                    </div>

                                    ${studioName ? `
                                        <div style="display: flex; align-items: baseline; gap: 6px; flex-wrap: wrap;">
                                            <label style="display: inline-flex; align-items: baseline; gap: 4px; min-width: 55px; flex-shrink: 0; cursor: pointer; user-select: none; font-weight: 600; color: ${isDark ? '#a5b4fc' : '#4f46e5'}; font-size: 11px;">
                                                <input type="checkbox" id="fasttag-scrape-chk-studio" checked style="cursor: pointer; width: 12px; height: 12px; accent-color: ${isStudioNew ? '#f59e0b' : '#6366f1'}; margin: 0; position: relative; top: 1.5px;">
                                                <span style="font-size: 11px;">🏢</span>
                                                <span>Studio:</span>
                                            </label>
                                            ${isStudioNew ? `
                                                <span style="display: inline-flex; align-items: baseline; gap: 4px; max-width: calc(100% - 75px); background: ${isDark ? 'rgba(245, 158, 11, 0.12)' : '#fef3c7'}; color: ${isDark ? '#fde68a' : '#92400e'}; border: 1px dashed ${isDark ? 'rgba(245, 158, 11, 0.55)' : '#f59e0b'}; padding: 2px 7px; border-radius: 4px; font-weight: 600; font-size: 11px;" title="Not in your local library — will create new studio upon saving">
                                                    <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${escapeHtml(studioName)}</span>
                                                    <span style="font-size: 8.5px; font-weight: 700; background: ${isDark ? 'rgba(245, 158, 11, 0.3)' : 'rgba(245, 158, 11, 0.25)'}; padding: 0.5px 3.5px; border-radius: 3px; color: ${isDark ? '#fef08a' : '#78350f'}; flex-shrink: 0;">+ New</span>
                                                </span>
                                            ` : `
                                                <span style="display: inline-block; max-width: calc(100% - 75px); background: ${isDark ? 'rgba(99, 102, 241, 0.2)' : '#e0e7ff'}; color: ${isDark ? '#e0e7ff' : '#312e81'}; padding: 2px 7px; border-radius: 4px; font-weight: 600; font-size: 11px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; vertical-align: middle;" title="Exists in your local library">${escapeHtml(studioName)}</span>
                                            `}
                                        </div>
                                    ` : ''}
                                </div>
                            ` : `
                                <!-- Docked Mode: Compact Side-by-Side -->
                                <div style="display: flex; gap: 9px; align-items: stretch;">
                                    ${match.image ? `
                                        <div class="fasttag-scrape-cover-thumb" style="flex-shrink: 0; width: 116px; height: 74px; border-radius: 6px; overflow: hidden; background: #000; border: 1px solid ${isDark ? 'rgba(255,255,255,0.18)' : '#cbd5e1'}; display: flex; align-items: center; justify-content: center; align-self: flex-start; cursor: pointer; position: relative; transition: all 0.15s ease;" title="Hover to view full-size cover">
                                            <img src="${match.image}" alt="Cover" style="width: 100%; height: 100%; object-fit: cover; display: block;" loading="lazy" />
                                            <label style="position: absolute; left: 4px; bottom: 4px; z-index: 2; display: inline-flex; align-items: center; gap: 3px; padding: 2px 5px; border-radius: 3px; background: rgba(15, 23, 42, 0.88); color: #e0e7ff; font-size: 9px; font-weight: 700; cursor: pointer; user-select: none;" title="Include this cover image when accepting the match">
                                                <input type="checkbox" id="fasttag-scrape-chk-cover" checked style="cursor: pointer; width: 10px; height: 10px; accent-color: #6366f1; margin: 0;">
                                                <span>Cover</span>
                                            </label>
                                        </div>
                                    ` : ''}
                                    <div style="display: flex; flex-direction: column; gap: 6px; justify-content: center; flex: 1; min-width: 0;">
                                        <!-- Title Row -->
                                        <div style="display: flex; align-items: baseline; gap: 6px; flex-wrap: wrap;">
                                            <label style="display: inline-flex; align-items: baseline; gap: 4px; min-width: 60px; flex-shrink: 0; cursor: pointer; user-select: none; font-weight: 600; color: ${isDark ? '#e0e7ff' : '#312e81'}; font-size: 11px;" title="Check to update scene title">
                                                <input type="checkbox" id="fasttag-scrape-chk-title" style="cursor: pointer; width: 12px; height: 12px; accent-color: #6366f1; margin: 0; position: relative; top: 1.5px;">
                                                <span style="font-size: 11px;">✏️</span>
                                                <span>Title:</span>
                                            </label>
                                            <span style="display: inline-block; max-width: calc(100% - 75px); background: ${isDark ? 'rgba(99, 102, 241, 0.2)' : '#e0e7ff'}; color: ${isDark ? '#e0e7ff' : '#312e81'}; padding: 2px 7px; border-radius: 4px; font-weight: 700; font-size: 11px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; vertical-align: middle;" title="${escapeHtml(match.title || '')}">${escapeHtml(match.title || 'Untitled Match')}</span>
                                            ${match.date ? `
                                                <label style="display: inline-flex; align-items: baseline; gap: 4px; font-size: 10.5px; color: ${isDark ? '#94a3b8' : '#64748b'}; font-weight: 500; cursor: pointer; user-select: none;" title="Include this date when accepting the match">
                                                    <input type="checkbox" id="fasttag-scrape-chk-date" checked style="cursor: pointer; width: 11px; height: 11px; accent-color: #0ea5e9; margin: 0; position: relative; top: 1px;">
                                                    <span>📅 ${escapeHtml(match.date)}</span>
                                                </label>
                                            ` : ''}
                                        </div>

                                        ${studioName ? `
                                            <div style="display: flex; align-items: baseline; gap: 6px; flex-wrap: wrap;">
                                                <label style="display: inline-flex; align-items: baseline; gap: 4px; min-width: 60px; flex-shrink: 0; cursor: pointer; user-select: none; font-weight: 600; color: ${isDark ? '#a5b4fc' : '#4f46e5'}; font-size: 11px;">
                                                    <input type="checkbox" id="fasttag-scrape-chk-studio" checked style="cursor: pointer; width: 12px; height: 12px; accent-color: ${isStudioNew ? '#f59e0b' : '#6366f1'}; margin: 0; position: relative; top: 1.5px;">
                                                    <span style="font-size: 11px;">🏢</span>
                                                    <span>Studio:</span>
                                                </label>
                                                ${isStudioNew ? `
                                                    <span style="display: inline-flex; align-items: baseline; gap: 4px; max-width: calc(100% - 75px); background: ${isDark ? 'rgba(245, 158, 11, 0.12)' : '#fef3c7'}; color: ${isDark ? '#fde68a' : '#92400e'}; border: 1px dashed ${isDark ? 'rgba(245, 158, 11, 0.55)' : '#f59e0b'}; padding: 2px 7px; border-radius: 4px; font-weight: 600; font-size: 11px;" title="Not in your local library — will create new studio upon saving">
                                                        <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${escapeHtml(studioName)}</span>
                                                        <span style="font-size: 8.5px; font-weight: 700; background: ${isDark ? 'rgba(245, 158, 11, 0.3)' : 'rgba(245, 158, 11, 0.25)'}; padding: 0.5px 3.5px; border-radius: 3px; color: ${isDark ? '#fef08a' : '#78350f'}; flex-shrink: 0;">+ New</span>
                                                    </span>
                                                ` : `
                                                    <span style="display: inline-block; max-width: calc(100% - 75px); background: ${isDark ? 'rgba(99, 102, 241, 0.2)' : '#e0e7ff'}; color: ${isDark ? '#e0e7ff' : '#312e81'}; padding: 2px 7px; border-radius: 4px; font-weight: 600; font-size: 11px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; vertical-align: middle;" title="Exists in your local library">${escapeHtml(studioName)}</span>
                                                `}
                                            </div>
                                        ` : ''}
                                    </div>
                                </div>
                            `}

                            <!-- Full-Width Performers, Tags, Details Sections -->
                            <div style="display: flex; flex-direction: column; gap: 5px; border-top: 1px solid ${isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)'}; padding-top: 5px;">
                                ${performers.length > 0 ? `
                                    <div style="display: flex; flex-direction: column; gap: 3px;">
                                        <div style="display: flex; align-items: baseline; justify-content: space-between;">
                                            <label style="display: inline-flex; align-items: baseline; gap: 4px; cursor: pointer; user-select: none; font-weight: 600; color: ${isDark ? '#7dd3fc' : '#0284c7'}; font-size: 11px;">
                                                <input type="checkbox" id="fasttag-scrape-chk-perf-all" checked style="cursor: pointer; width: 12px; height: 12px; accent-color: #0ea5e9; margin: 0; position: relative; top: 1.5px;">
                                                <span style="font-size: 11px;">👥</span>
                                                <span>Performers (${performers.length}):</span>
                                            </label>
                                        </div>
                                        <div id="fasttag-scrape-perf-pills" style="display: flex; flex-wrap: wrap; gap: 4px;">
                                            ${performers.map((p, pIdx) => {
                                                const isNew = !(p.stored_id || cachedPerformers.some(cp => (cp.name || '').trim().toLowerCase() === (p.name || '').trim().toLowerCase()));
                                                if (isNew) {
                                                    return `
                                                        <label class="fasttag-performer-hover-trigger" data-scrape-performer-index="${pIdx}" style="display: inline-flex; align-items: baseline; gap: 4px; background: ${isDark ? 'rgba(245, 158, 11, 0.12)' : '#fef3c7'}; color: ${isDark ? '#fde68a' : '#92400e'}; border: 1px dashed ${isDark ? 'rgba(245, 158, 11, 0.55)' : '#f59e0b'}; padding: 2px 6px; border-radius: 4px; font-size: 10px; cursor: pointer; user-select: none;">
                                                            <input type="checkbox" class="fasttag-scrape-perf-item" data-idx="${pIdx}" checked style="cursor: pointer; width: 11px; height: 11px; accent-color: #f59e0b; margin: 0; position: relative; top: 1.5px;">
                                                            <span>${escapeHtml(p.name)}</span>
                                                            <span style="font-size: 8.5px; font-weight: 700; background: ${isDark ? 'rgba(245, 158, 11, 0.3)' : 'rgba(245, 158, 11, 0.25)'}; padding: 0.5px 3.5px; border-radius: 3px; color: ${isDark ? '#fef08a' : '#78350f'};">+ New</span>
                                                        </label>
                                                    `;
                                                }
                                                return `
                                                    <label class="fasttag-performer-hover-trigger" data-scrape-performer-index="${pIdx}" style="display: inline-flex; align-items: baseline; gap: 4px; background: ${isDark ? 'rgba(14, 165, 233, 0.15)' : '#e0f2fe'}; color: ${isDark ? '#bae6fd' : '#0369a1'}; border: 1px solid ${isDark ? 'rgba(56, 189, 248, 0.35)' : '#7dd3fc'}; padding: 2px 6px; border-radius: 4px; font-size: 10px; cursor: pointer; user-select: none;">
                                                        <input type="checkbox" class="fasttag-scrape-perf-item" data-idx="${pIdx}" checked style="cursor: pointer; width: 11px; height: 11px; accent-color: #0ea5e9; margin: 0; position: relative; top: 1.5px;">
                                                        <span>${escapeHtml(p.name)}</span>
                                                    </label>
                                                `;
                                            }).join('')}
                                        </div>
                                    </div>
                                ` : ''}

                                ${tags.length > 0 ? `
                                    <div style="display: flex; flex-direction: column; gap: 3px;">
                                        <div style="display: flex; align-items: baseline; justify-content: space-between;">
                                            <label style="display: inline-flex; align-items: baseline; gap: 4px; cursor: pointer; user-select: none; font-weight: 600; color: ${isDark ? '#cbd5e1' : '#475569'}; font-size: 11px;">
                                                <input type="checkbox" id="fasttag-scrape-chk-tags-all" style="cursor: pointer; width: 12px; height: 12px; accent-color: #64748b; margin: 0; position: relative; top: 1.5px;">
                                                <span style="font-size: 11px;">🏷️</span>
                                                <span>Tags (${tags.length}):</span>
                                            </label>
                                        </div>
                                        <div id="fasttag-scrape-tags-pills" style="display: flex; flex-wrap: wrap; gap: 3px; align-items: baseline;">
                                            ${tags.map((t, tIdx) => {
                                                const isNew = !(t.stored_id || cachedTags.some(ct => (ct.name || '').trim().toLowerCase() === (t.name || '').trim().toLowerCase()));
                                                if (isNew) {
                                                    return `
                                                        <label style="display: inline-flex; align-items: baseline; gap: 3px; background: ${isDark ? 'rgba(245, 158, 11, 0.1)' : '#fffbeb'}; color: ${isDark ? '#fde68a' : '#92400e'}; border: 1px dashed ${isDark ? 'rgba(245, 158, 11, 0.5)' : '#fbbf24'}; padding: 1.5px 5px; border-radius: 4px; font-size: 9.5px; cursor: pointer; user-select: none;" title="Not in your local library — will create new tag upon saving">
                                                            <input type="checkbox" class="fasttag-scrape-tag-item" data-idx="${tIdx}" style="cursor: pointer; width: 10px; height: 10px; accent-color: #f59e0b; margin: 0; position: relative; top: 1px;">
                                                            <span>${escapeHtml(t.name)}</span>
                                                            <span style="font-size: 8px; font-weight: 700; background: ${isDark ? 'rgba(245, 158, 11, 0.28)' : 'rgba(245, 158, 11, 0.2)'}; padding: 0.5px 3px; border-radius: 2px; color: ${isDark ? '#fef08a' : '#78350f'};">+ New</span>
                                                        </label>
                                                    `;
                                                }
                                                return `
                                                    <label style="display: inline-flex; align-items: baseline; gap: 3px; background: ${isDark ? 'rgba(148, 163, 184, 0.12)' : '#f1f5f9'}; color: ${isDark ? '#cbd5e1' : '#334155'}; border: 1px solid ${isDark ? 'rgba(148, 163, 184, 0.3)' : '#cbd5e1'}; padding: 1.5px 5px; border-radius: 4px; font-size: 9.5px; cursor: pointer; user-select: none;" title="Exists in your local library">
                                                        <input type="checkbox" class="fasttag-scrape-tag-item" data-idx="${tIdx}" style="cursor: pointer; width: 10px; height: 10px; accent-color: #64748b; margin: 0; position: relative; top: 1px;">
                                                        <span>${escapeHtml(t.name)}</span>
                                                    </label>
                                                `;
                                            }).join('')}
                                        </div>
                                    </div>
                                ` : ''}

                                ${match.details && match.details.trim() ? `
                                    <div style="display: flex; flex-direction: column; gap: 4px; margin-top: 2px; border-top: 1px solid ${isDark ? 'rgba(255,255,255,0.06)' : '#e2e8f0'}; padding-top: 4px;">
                                        <div style="display: flex; align-items: baseline; gap: 6px; flex-wrap: wrap;">
                                            <label style="display: inline-flex; align-items: baseline; gap: 4px; min-width: 60px; flex-shrink: 0; cursor: pointer; user-select: none; font-weight: 600; font-size: 11px; color: ${isDark ? '#93c5fd' : '#2563eb'};">
                                                <input type="checkbox" id="fasttag-scrape-chk-details" style="cursor: pointer; width: 12px; height: 12px; accent-color: #3b82f6; margin: 0; position: relative; top: 1.5px;">
                                                <span style="font-size: 11px;">📜</span>
                                                <span>Details:</span>
                                            </label>
                                            <span id="fasttag-scrape-toggle-details" style="display: inline-flex; align-items: baseline; gap: 5px; background: ${isDark ? 'rgba(99, 102, 241, 0.2)' : '#e0e7ff'}; color: ${isDark ? '#c7d2fe' : '#3730a3'}; border: 1px solid ${isDark ? 'rgba(99, 102, 241, 0.35)' : '#c7d2fe'}; padding: 2px 7px; border-radius: 4px; font-weight: 500; font-size: 10.5px; cursor: pointer; max-width: 410px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; user-select: none; transition: background 0.15s ease;" title="Click to expand/collapse full synopsis">
                                                <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-style: italic;">"${escapeHtml(match.details.trim().replace(/\s+/g, ' '))}"</span>
                                                <span id="fasttag-scrape-details-arrow" style="font-size: 7.5px; color: #818cf8; flex-shrink: 0;">▶</span>
                                            </span>
                                        </div>
                                        <div id="fasttag-scrape-details-content" style="display: none; max-height: 110px; overflow-y: auto; font-size: 11.5px; line-height: 1.5; color: ${isDark ? '#e2e8f0' : '#1e293b'}; background: ${isDark ? 'rgba(0,0,0,0.45)' : '#ffffff'}; padding: 7px 10px; border-radius: 5px; border: 1px solid ${isDark ? 'rgba(255,255,255,0.12)' : '#cbd5e1'}; white-space: pre-wrap; word-break: break-word; font-family: system-ui, -apple-system, sans-serif;">
                                            ${escapeHtml(match.details.trim())}
                                        </div>
                                    </div>
                                ` : ''}
                            </div>
                        </div>

                        <!-- Guaranteed Visible Bottom Scroll Indicator -->
                        <div id="fasttag-scrape-scroll-hint" style="display: none; position: absolute; bottom: 0; left: 0; right: 0; height: 28px; background: linear-gradient(to top, ${isDark ? 'rgba(30, 41, 59, 0.95)' : 'rgba(241, 245, 249, 0.95)'} 25%, transparent 100%); pointer-events: none; align-items: flex-end; justify-content: center; padding-bottom: 2px; transition: opacity 0.2s ease;">
                            <span style="font-size: 9px; font-weight: 600; color: #818cf8; display: inline-flex; align-items: center; gap: 3px; background: ${isDark ? '#1e293b' : '#ffffff'}; padding: 1px 7px; border-radius: 10px; border: 1px solid rgba(129, 140, 248, 0.4); box-shadow: 0 1px 4px rgba(0,0,0,0.3);">
                                <span>⌄</span><span>More below</span>
                            </span>
                        </div>
                    </div>

                    <!-- Seamless Edge Resizer (Zero wasted height, cursor: ns-resize) -->
                    <div id="fasttag-scrape-v-resizer" style="height: 11px; margin: 3px -12px -6px -12px; cursor: ns-resize; border-bottom: 2px solid rgba(99, 102, 241, 0.45); display: ${isDetached ? 'none' : 'flex'}; align-items: center; justify-content: center; user-select: none; transition: border-color 0.15s ease;" title="Drag up or down to resize scraper preview height">
                        <div style="width: 44px; height: 3px; border-radius: 2px; background: rgba(129, 140, 248, 0.6); pointer-events: none; transition: all 0.15s ease;"></div>
                    </div>
                </div>
            `;

            const scraperHeader = targetContainer.querySelector('#fasttag-scrape-header');
            const scraperHeaderPrimary = targetContainer.querySelector('#fasttag-scrape-header-primary');
            const scraperHeaderActions = targetContainer.querySelector('#fasttag-scrape-header-actions');
            const scraperSourceLabelElement = targetContainer.querySelector('#fasttag-scrape-source-label');
            const scraperMatchCounterElement = targetContainer.querySelector('#fasttag-scrape-match-counter');
            const scraperDockLabelElement = targetContainer.querySelector('#fasttag-scrape-dock-label');
            if (isDetached) dependencies.mountMomentaryPeekButton?.(targetContainer, scraperHeaderActions);
            const updateScraperHeaderLayout = () => {
                if (!scraperHeader || !scraperHeaderPrimary || !scraperHeaderActions) return;
                // Keep navigation and actions on one row at every HUD width. At very
                // small widths only redundant text is hidden; the controls themselves
                // remain available through their icons and tooltips.
                scraperHeader.style.display = 'flex';
                scraperHeader.style.gridTemplateColumns = '';
                scraperHeader.style.gridTemplateRows = '';
                scraperHeader.style.height = 'auto';
                scraperHeader.style.minHeight = '26px';
                scraperHeader.style.alignItems = 'center';
                scraperHeaderPrimary.style.flex = '1 1 150px';
                scraperHeaderPrimary.style.width = 'auto';
                scraperHeaderActions.style.alignSelf = 'auto';
                scraperHeaderActions.style.justifySelf = 'auto';
                const availableWidth = scraperHeader.clientWidth || targetContainer.getBoundingClientRect?.().width || targetContainer.clientWidth || 0;
                const tight = getScraperHeaderDensity(availableWidth) === 'tight';
                if (scraperSourceLabelElement) {
                    scraperSourceLabelElement.style.maxWidth = tight ? '68px' : '95px';
                }
                if (scraperDockLabelElement) scraperDockLabelElement.style.display = tight ? 'none' : '';
                if (scraperMatchCounterElement) {
                    scraperMatchCounterElement.style.width = tight ? '82px' : '92px';
                    scraperMatchCounterElement.style.flexBasis = tight ? '82px' : '92px';
                }
            };
            targetContainer._fastTagScraperHeaderResizeObserver?.disconnect?.();
            updateScraperHeaderLayout();
            let scraperHeaderLayoutFramePending = false;
            const recheckScraperHeaderLayout = () => {
                if (scraperHeaderLayoutFramePending) return;
                scraperHeaderLayoutFramePending = true;
                const runCheck = () => {
                    scraperHeaderLayoutFramePending = false;
                    if (scraperHeader?.isConnected === false) return;
                    updateScraperHeaderLayout();
                };
                if (typeof root.requestAnimationFrame === 'function') root.requestAnimationFrame(runCheck);
                else root.setTimeout(runCheck, 0);
            };
            targetContainer._fastTagRecheckScraperHeaderLayout = recheckScraperHeaderLayout;
            recheckScraperHeaderLayout();
            root.setTimeout(updateScraperHeaderLayout, 80);
            root.setTimeout(updateScraperHeaderLayout, 240);
            root.document?.fonts?.ready?.then?.(recheckScraperHeaderLayout).catch?.(() => {});
            if (typeof root.ResizeObserver === 'function') {
                targetContainer._fastTagScraperHeaderResizeObserver = new root.ResizeObserver(recheckScraperHeaderLayout);
                targetContainer._fastTagScraperHeaderResizeObserver.observe(targetContainer);
            }

            const previewBox = targetContainer.querySelector('#fasttag-scrape-items-preview');
            const perfPills = targetContainer.querySelector('#fasttag-scrape-perf-pills');
            const tagsPills = targetContainer.querySelector('#fasttag-scrape-tags-pills');

            const runManualSearch = async () => {
                const input = targetContainer.querySelector('#fasttag-scrape-manual-query');
                const searchBtn = targetContainer.querySelector('#fasttag-scrape-manual-search-btn');
                const query = (input?.value || '').trim();
                if (!query) {
                    toastError('Enter the words you want to search for.');
                    input?.focus();
                    return;
                }
                const manualRequestId = beginRequest(popup, sceneId);
                if (manualRequestId == null) return;
                if (searchBtn) {
                    searchBtn.disabled = true;
                    searchBtn.textContent = 'Searching…';
                }
                try {
                    const manualResults = await fetchScraperMatchesForScene(
                        sceneId,
                        null,
                        query,
                        () => isRequestCurrent(popup, sceneId, manualRequestId),
                        dependencies?.getActiveScraperSource?.() || activeSource?.id
                    );
                    if (!isRequestCurrent(popup, sceneId, manualRequestId)) return;
                    if (!manualResults?.length) {
                        toastError(`No scraper matches found for “${query}”`);
                        if (searchBtn) {
                            searchBtn.disabled = false;
                            searchBtn.textContent = 'Search';
                        }
                        return;
                    }
                    sessionCache.set(sceneId, manualResults);
                    hideScrapeCoverTooltip();
                    await renderMatches(container, manualResults, sceneId, ctx, popup, onDismiss, '', manualRequestId);
                } catch (error) {
                    if (!isRequestCurrent(popup, sceneId, manualRequestId)) return;
                    toastError('Scrape search failed: ' + (error?.message || error));
                    if (searchBtn) {
                        searchBtn.disabled = false;
                        searchBtn.textContent = 'Search';
                    }
                }
            };

            const manualSearchBtn = targetContainer.querySelector('#fasttag-scrape-manual-search-btn');
            if (manualSearchBtn) manualSearchBtn.onclick = runManualSearch;
            const manualSearchInput = targetContainer.querySelector('#fasttag-scrape-manual-query');
            if (manualSearchInput) {
                manualSearchInput.onkeydown = (event) => {
                    if (event.key !== 'Enter') return;
                    event.preventDefault();
                    event.stopPropagation();
                    runManualSearch();
                };
            }

            const toggleHiddenBtn = targetContainer.querySelector('#fasttag-scrape-toggle-hidden');
            if (toggleHiddenBtn) {
                toggleHiddenBtn.onclick = (event) => {
                    event.preventDefault();
                    event.stopPropagation();
                    const wasShowing = showingHiddenResults;
                    allResults._fastTagShowHidden = !wasShowing;
                    allResults._fastTagShowAllResults = !wasShowing;
                    // Jump to the first newly revealed item when showing hidden results
                    if (!wasShowing) {
                        allResults._fastTagInitialIndex = falsePositivePartition.visible.length;
                    }
                    hideScrapeCoverTooltip();
                    renderMatches(container, allResults, sceneId, ctx, popup, onDismiss, '', scrapeRequestId);
                };
            }

            const toggleOverflowBtn = targetContainer.querySelector('#fasttag-scrape-toggle-overflow');
            if (toggleOverflowBtn) {
                toggleOverflowBtn.onclick = (event) => {
                    event.preventDefault();
                    event.stopPropagation();
                    const wasShowingAll = showingAllResults;
                    allResults._fastTagShowAllResults = !wasShowingAll;
                    // Jump to the first newly revealed item when expanding beyond the limit
                    if (!wasShowingAll) {
                        allResults._fastTagInitialIndex = initialResultLimit;
                    }
                    hideScrapeCoverTooltip();
                    renderMatches(container, allResults, sceneId, ctx, popup, onDismiss, '', scrapeRequestId);
                };
            }

            const dismissMatchBtn = targetContainer.querySelector('#fasttag-scrape-dismiss-match');
            if (dismissMatchBtn) {
                dismissMatchBtn.onclick = (event) => {
                    event.preventDefault();
                    event.stopPropagation();
                    hideScrapeCoverTooltip();
                    const selectedMatch = results[currentIndex];
                    const sourceIndex = allResults.indexOf(selectedMatch);
                    if (sourceIndex >= 0) allResults.splice(sourceIndex, 1);
                    if (allResults.length === 0) {
                        sessionCache.delete(sceneId);
                        renderMatches(container, allResults, sceneId, ctx, popup, onDismiss, '', scrapeRequestId);
                        if (typeof onDismiss === 'function') onDismiss();
                        return;
                    }
                    sessionCache.set(sceneId, allResults);
                    renderMatches(container, allResults, sceneId, ctx, popup, onDismiss, '', scrapeRequestId);
                };
            }

            // Wire popout / dock button
            const popoutToggleBtn = targetContainer.querySelector('#fasttag-scrape-popout-toggle');
            if (popoutToggleBtn) {
                popoutToggleBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    hideScrapeCoverTooltip();
                    const nextState = !getDetachScraper();
                    setDetachScraper(nextState);
                    if (nextState) {
                        if (popup?.scraperCardContainer) {
                            popup.scraperCardContainer.innerHTML = '';
                            popup.scraperCardContainer.style.display = 'none';
                        }
                    } else {
                        closeHud();
                    }
                    renderMatches(popup?.scraperCardContainer || container, allResults, sceneId, ctx, popup, onDismiss, '', scrapeRequestId);
                };
            }

            // Wire dragging when in detached floating window
            if (isDetached && floatingScraperHudElement) {
                const headerEl = targetContainer.querySelector('#fasttag-scrape-header');
                attachHudDragging(floatingScraperHudElement, headerEl);
            }

            // Wire scraper source switcher button
            const sourceBtn = targetContainer.querySelector('#fasttag-scrape-source-btn');
            if (sourceBtn) {
                attachSourceDropdown(sourceBtn, popup, sceneId, handleSourceChange);
            }

            // Wire vertical resize dragging (allows smooth split resizing between scraper card and tags table)
            const resizer = targetContainer.querySelector('#fasttag-scrape-v-resizer');
            if (resizer && previewBox) {
                if (isDetached) {
                    resizer.style.display = 'none';
                } else {
                    resizer.style.display = 'flex';
                }
                let isResizing = false;
                let startY = 0;
                let startPreviewH = 0;

                const onMouseMove = (e) => {
                    if (!isResizing) return;
                    e.preventDefault();
                    const dy = e.clientY - startY;
                    const newPreviewH = Math.max(50, Math.min(520, startPreviewH + dy));
                    previewBox.style.height = `${newPreviewH}px`;
                    try {
                        root.localStorage.setItem('fasttag_embedded_scraper_h', String(newPreviewH));
                    } catch (e) {}
                    if (typeof updateScrollHint === 'function') updateScrollHint();
                    if (activeTableInstance) {
                        try { activeTableInstance.redraw(false); } catch (err) {}
                    }
                    if (popup?.tagsTable) {
                        try { popup.tagsTable.redraw(false); } catch (err) {}
                    }
                    if (popup?.performersTable) {
                        try { popup.performersTable.redraw(false); } catch (err) {}
                    }
                };

                const onMouseUp = () => {
                    if (isResizing) {
                        isResizing = false;
                        document.removeEventListener('mousemove', onMouseMove);
                        document.removeEventListener('mouseup', onMouseUp);
                        document.body.style.cursor = '';
                        document.body.style.userSelect = '';
                        resizer.style.borderBottomColor = 'rgba(99, 102, 241, 0.45)';
                        const bar = resizer.querySelector('div');
                        if (bar) {
                            bar.style.width = '44px';
                            bar.style.background = 'rgba(129, 140, 248, 0.6)';
                        }
                    }
                };

                resizer.addEventListener('mouseenter', () => {
                    resizer.style.borderBottomColor = '#818cf8';
                    const bar = resizer.querySelector('div');
                    if (bar) {
                        bar.style.width = '64px';
                        bar.style.background = '#818cf8';
                    }
                });

                resizer.addEventListener('mouseleave', () => {
                    if (!isResizing) {
                        resizer.style.borderBottomColor = 'rgba(99, 102, 241, 0.45)';
                        const bar = resizer.querySelector('div');
                        if (bar) {
                            bar.style.width = '44px';
                            bar.style.background = 'rgba(129, 140, 248, 0.6)';
                        }
                    }
                });

                resizer.addEventListener('mousedown', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    isResizing = true;
                    startY = e.clientY;
                    startPreviewH = previewBox.offsetHeight || 180;
                    document.body.style.cursor = 'ns-resize';
                    document.body.style.userSelect = 'none';
                    document.addEventListener('mousemove', onMouseMove);
                    document.addEventListener('mouseup', onMouseUp);
                });

                resizer.addEventListener('mouseenter', () => {
                    const bar = resizer.querySelector('div');
                    if (bar) {
                        bar.style.width = '64px';
                        bar.style.background = '#818cf8';
                    }
                });
                resizer.addEventListener('mouseleave', () => {
                    if (!isResizing) {
                        const bar = resizer.querySelector('div');
                        if (bar) {
                            bar.style.width = '44px';
                            bar.style.background = isDark ? 'rgba(255,255,255,0.3)' : '#94a3b8';
                        }
                    }
                });
            }

            // Toggle Synopsis / Details blurb
            const detailsToggleBtn = targetContainer.querySelector('#fasttag-scrape-toggle-details');
            const detailsContent = targetContainer.querySelector('#fasttag-scrape-details-content');
            const detailsArrow = targetContainer.querySelector('#fasttag-scrape-details-arrow');
            if (detailsToggleBtn && detailsContent) {
                detailsToggleBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    const isHidden = detailsContent.style.display === 'none';
                    detailsContent.style.display = isHidden ? 'block' : 'none';
                    if (detailsArrow) detailsArrow.textContent = isHidden ? '▼' : '▶';
                    detailsToggleBtn.title = isHidden ? 'Click to collapse synopsis' : 'Click to expand full synopsis';
                };
            }

            // Hover zoom tooltip for cover image
            const thumbEl = targetContainer.querySelector('.fasttag-scrape-cover-thumb');
            if (thumbEl && match.image) {
                thumbEl.onmouseenter = () => showScrapeCoverTooltip(match.image, thumbEl);
                thumbEl.onmouseleave = () => hideScrapeCoverTooltip();
            }

            targetContainer.querySelectorAll('.fasttag-performer-hover-trigger').forEach(trigger => {
                const performerIndex = Number(trigger.getAttribute('data-scrape-performer-index'));
                const performer = performers[performerIndex];
                if (!performer) return;
                trigger.onmouseenter = () => startScrapedPerformerHover(performer, match, cachedPerformers, trigger);
                trigger.onmouseleave = (event) => {
                    if (event.relatedTarget?.closest?.('#fasttag-performer-hover-card')) return;
                    stopScrapedPerformerHover();
                };
            });

            // Bind interactions
            const prevBtn = targetContainer.querySelector('#fasttag-scrape-prev');
            if (prevBtn) {
                prevBtn.onclick = (e) => {
                    e.preventDefault();
                    hideScrapeCoverTooltip();
                    if (currentIndex > 0) {
                        currentIndex--;
                        updateCardView();
                    }
                };
            }

            const nextBtn = targetContainer.querySelector('#fasttag-scrape-next');
            if (nextBtn) {
                nextBtn.onclick = (e) => {
                    e.preventDefault();
                    hideScrapeCoverTooltip();
                    if (currentIndex < results.length - 1) {
                        currentIndex++;
                        updateCardView();
                    }
                };
            }

            const perfAllChk = targetContainer.querySelector('#fasttag-scrape-chk-perf-all');
            if (perfAllChk) {
                perfAllChk.onchange = (e) => {
                    targetContainer.querySelectorAll('.fasttag-scrape-perf-item').forEach(chk => {
                        chk.checked = e.target.checked;
                    });
                };
            }

            const tagsAllChk = targetContainer.querySelector('#fasttag-scrape-chk-tags-all');
            if (tagsAllChk) {
                tagsAllChk.onchange = (e) => {
                    targetContainer.querySelectorAll('.fasttag-scrape-tag-item').forEach(chk => {
                        chk.checked = e.target.checked;
                    });
                };
            }

            const cancelBtn = targetContainer.querySelector('#fasttag-scrape-cancel-btn');
            if (cancelBtn) {
                cancelBtn.onclick = (e) => {
                    e.preventDefault();
                    invalidateRequests(popup);
                    hideScrapeCoverTooltip();
                    restoreSingleWidth();
                    closeHud();
                    targetContainer.innerHTML = '';
                    targetContainer.style.display = 'none';
                    if (typeof onDismiss === 'function') onDismiss();
                };
            }

            const scrollHint = targetContainer.querySelector('#fasttag-scrape-scroll-hint');
            const updateScrollHint = () => {
                if (!previewBox || !scrollHint) return;
                const canScrollDown = previewBox.scrollHeight > (previewBox.clientHeight + 6) && ((previewBox.scrollTop + previewBox.clientHeight) < (previewBox.scrollHeight - 8));
                scrollHint.style.display = canScrollDown ? 'flex' : 'none';
            };

            if (previewBox) {
                previewBox.onscroll = updateScrollHint;
                setTimeout(updateScrollHint, 60);
            }

            const acceptBtn = targetContainer.querySelector('#fasttag-scrape-accept-btn');
            if (acceptBtn) {
                acceptBtn.onclick = async (e) => {
                    e.preventDefault();
                    hideScrapeCoverTooltip();
                    acceptBtn.disabled = true;
                    acceptBtn.innerHTML = `<span>⏳ Saving...</span>`;
                    await acceptMatch(match, targetContainer, sceneId, ctx, popup);
                };
            }

            if (popup && popup.scrapeBtn) {
                popup.scrapeBtn.innerHTML = isEasterEggActive() ? '<span>▲ Hide 🍫</span>' : '<span>▲ Hide</span>';
                popup.scrapeBtn.title = isDetached ? 'Hide detached scraper window' : 'Hide scrape preview';
                if (isDetached) {
                    popup.scrapeBtn.classList.add('fasttag-dock-pulse');
                } else {
                    popup.scrapeBtn.classList.remove('fasttag-dock-pulse');
                }
            }

            if (isDetached && floatingScraperHudElement) {
                attachResizeHandles(floatingScraperHudElement);
            }
        };

        updateCardView();
        const activeEl = root.document?.activeElement;
        const isUserInScraperInput = targetContainer && typeof targetContainer.contains === "function" && targetContainer.contains(activeEl) && (activeEl.tagName === "INPUT" || activeEl.tagName === "TEXTAREA");
        if (!isUserInScraperInput) {
            const mainSearch = popup?.globalSearch || popup?.searchInput || popup?.element?.querySelector?.("#everything-global-search, input[type=\"text\"], input[type=\"search\"]");
            if (mainSearch && root.document?.body?.contains(mainSearch)) {
                mainSearch.focus({ preventScroll: true });
            }
        }
    }


    async function acceptMatch(match, container, sceneId, ctx, popup) {
        if (!dependencies) throw new Error('[FastTag] Scraper controller is not configured');
        const {
            log: ftLog,
            readScrapeFieldSelection,
            resolveScrapedStudioResult,
            resolveScrapedEntityIdsResult,
            fetchGQL,
            buildAcceptedSceneStashIds,
            buildScrapeUpdateInput,
            sceneCardUpdateFields: SCENE_CARD_UPDATE_FIELDS,
            syncSceneToApolloCache,
            setLiveEverythingPopupTitle,
            refreshSceneCards,
            scheduleSceneCardRefreshAfterRename,
            recordSaveUsage,
            toastError,
            toastSuccess
        } = dependencies;
        try {
            ftLog('ACTION', 'SCRAPE', `Accept match clicked for scene ${sceneId}: "${match.title || ''}"`, {
                sceneId,
                title: match.title,
                studio: match.studio?.name,
                performersCount: match.performers?.length,
                tagsCount: match.tags?.length,
                date: match.date
            });

            const scrapeSelection = readScrapeFieldSelection(container);

            // 1–3. Resolve studio, performers and tags against stored IDs and the local library.
            const studioResolution = await resolveScrapedStudioResult(match.studio, scrapeSelection.studio);
            const performerResolution = await resolveScrapedEntityIdsResult(
                'performers',
                match.performers,
                scrapeSelection.performerIndices,
                { endpoint: match._sourceEndpoint, name: match._sourceName }
            );
            const tagResolution = await resolveScrapedEntityIdsResult('tags', match.tags, scrapeSelection.tagIndices);
            const studioIdToSet = studioResolution.id;
            const performerIdsToAdd = performerResolution.ids;
            const tagIdsToAdd = tagResolution.ids;
            const resolutionFailures = [
                ...studioResolution.failures.map(name => `studio “${name}”`),
                ...performerResolution.failures.map(name => `performer “${name}”`),
                ...tagResolution.failures.map(name => `tag “${name}”`)
            ];
            const scraperSourceName = String(match?._sourceName || 'scraper source');
            const scraperIdLabel = `${scraperSourceName} ID`;

            // 4. Update Scene & Synchronize Context
            const effectiveCtx = ctx || popup?._context || dependencies.getActivePopup?.()?._context;
            const isEverythingModal = popup?.element?.getAttribute('data-popup-type') === 'everything' || popup?.element?.getAttribute('data-popup-type') === 'bulk-everything' || dependencies.getActivePopup?.()?.type === 'everything' || Boolean(effectiveCtx);

            if (isEverythingModal && effectiveCtx) {
                // Save scraper fields DIRECTLY. Do not route Accept through the general doSave()
                // mutation because that also includes unrelated fields (for example groups) and can
                // cause the whole GraphQL mutation to fail on Stash versions with a different schema.
                // Cover image is deliberately saved in a SECOND mutation so an image-specific error
                // cannot prevent title/studio/performers/date/details/tags from being saved.

                const sceneRes = await fetchGQL(`
                    query FastTagAcceptCurrentScene($id: ID!) {
                        findScene(id: $id) {
                            id
                            performers { id }
                            tags { id }
                            studio { id }
                            stash_ids { endpoint stash_id }
                        }
                    }
                `, { id: sceneId });

                if (sceneRes?.errors?.length) {
                    throw new Error(sceneRes.errors.map(e => e.message).join('; '));
                }

                const existingPerformerIds = (sceneRes?.data?.findScene?.performers || []).map(p => String(p.id));
                const existingTagIds = (sceneRes?.data?.findScene?.tags || []).map(t => String(t.id));
                let stashIdResolution = { stashIds: sceneRes?.data?.findScene?.stash_ids || [], added: false, reason: null };
                try {
                    const configRes = await fetchGQL(`query FastTagStashBoxes { configuration { general { stashBoxes { endpoint name } } } }`);
                    stashIdResolution = buildAcceptedSceneStashIds(
                        sceneRes?.data?.findScene?.stash_ids,
                        match,
                        configRes?.data?.configuration?.general?.stashBoxes
                    );
                } catch (error) {
                    if (match?.remote_site_id || match?.urls?.some?.(url => /^https?:\/\//i.test(url))) {
                        stashIdResolution.reason = 'the configured scraper endpoint could not be loaded';
                    }
                }
                if (stashIdResolution.reason) resolutionFailures.push(`${scraperIdLabel} (${stashIdResolution.reason})`);
                const { updateInput, mergedPerformerIds, mergedTagIds } = buildScrapeUpdateInput({
                    sceneId,
                    match,
                    selection: scrapeSelection,
                    studioIdToSet,
                    performerIdsToAdd,
                    tagIdsToAdd,
                    existingPerformerIds,
                    existingTagIds
                });

                const saveRes = await fetchGQL(`
                    mutation FastTagAcceptSave($input: SceneUpdateInput!) {
                        sceneUpdate(input: $input) {
                            ${SCENE_CARD_UPDATE_FIELDS}
                            title
                            date
                        }
                    }
                `, { input: updateInput });

                if (saveRes?.errors?.length || !saveRes?.data?.sceneUpdate?.id) {
                    const msg = saveRes?.errors?.map(e => e.message).join('; ') || 'Stash did not return a saved scene.';
                    throw new Error(msg);
                }

                syncSceneToApolloCache(saveRes.data.sceneUpdate);
                if (scrapeSelection.title && match.title) {
                    setLiveEverythingPopupTitle(popup, match.title);
                }

                // Save and verify the StashDB ID independently. Keeping this separate from the
                // metadata mutation makes any endpoint/ID problem visible without rolling back
                // title, studio, performer, tag, date or details changes that already succeeded.
                if (stashIdResolution.added) {
                    const expectedStashId = stashIdResolution.stashIds[stashIdResolution.stashIds.length - 1];
                    const stashIdSaveRes = await fetchGQL(`
                        mutation FastTagAcceptStashId($input: SceneUpdateInput!) {
                            sceneUpdate(input: $input) {
                                id
                                stash_ids { endpoint stash_id }
                            }
                        }
                    `, { input: { id: sceneId, stash_ids: stashIdResolution.stashIds } });
                    const returnedStashIds = stashIdSaveRes?.data?.sceneUpdate?.stash_ids || [];
                    const expectedEndpoint = String(expectedStashId.endpoint).replace(/\/+$/, '').toLowerCase();
                    const idWasSaved = returnedStashIds.some(item =>
                        String(item?.endpoint || '').replace(/\/+$/, '').toLowerCase() === expectedEndpoint
                        && String(item?.stash_id || '') === String(expectedStashId.stash_id)
                    );
                    if (stashIdSaveRes?.errors?.length || !idWasSaved) {
                        const reason = stashIdSaveRes?.errors?.map(error => error.message).join('; ')
                            || 'Stash did not return the accepted ID after saving';
                        resolutionFailures.push(`${scraperIdLabel} (${reason})`);
                    }
                }

                // Save cover separately. If Stash rejects the image value, all other metadata is
                // already safely committed and the user gets a warning rather than losing everything.
                let coverSaved = true;
                if (scrapeSelection.cover && match.image) {
                    const coverRes = await fetchGQL(`
                        mutation FastTagAcceptCover($input: SceneUpdateInput!) {
                            sceneUpdate(input: $input) { id }
                        }
                    `, { input: { id: sceneId, cover_image: match.image } });
                    if (coverRes?.errors?.length || !coverRes?.data?.sceneUpdate?.id) {
                        coverSaved = false;
                        console.warn('[FastTag] Cover image save failed:', coverRes?.errors || coverRes);
                    }
                }

                // Keep the Edit Everything popup state in sync with what was actually saved.
                if (typeof effectiveCtx.setSelectedStudio === 'function' && studioIdToSet) {
                    effectiveCtx.setSelectedStudio(studioIdToSet);
                }
                if (typeof effectiveCtx.setSelectedPerformers === 'function') {
                    effectiveCtx.setSelectedPerformers(new Set(mergedPerformerIds));
                }
                if (typeof effectiveCtx.setSelectedTags === 'function') {
                    effectiveCtx.setSelectedTags(new Set(mergedTagIds));
                }
                if (typeof effectiveCtx.setInitialStudio === 'function' && studioIdToSet) {
                    effectiveCtx.setInitialStudio(studioIdToSet);
                }
                if (typeof effectiveCtx.setInitialPerformers === 'function') {
                    effectiveCtx.setInitialPerformers(new Set(mergedPerformerIds));
                }
                if (typeof effectiveCtx.setInitialTags === 'function') {
                    effectiveCtx.setInitialTags(new Set(mergedTagIds));
                }

                // Inject newly created entities directly into active popup UI state
                const createdStudio = studioResolution?.createdEntity;
                const createdPerformers = performerResolution?.createdEntities || [];
                const createdTags = tagResolution?.createdEntities || [];

                if (createdStudio) {
                    if (typeof effectiveCtx.injectCreatedEntity === 'function') {
                        effectiveCtx.injectCreatedEntity('studios', createdStudio);
                    } else if (typeof dependencies.injectCachedEntity === 'function') {
                        dependencies.injectCachedEntity('studios', createdStudio);
                    }
                    if (popup?.studioBar?.chipName) {
                        popup.studioBar.chipName.textContent = createdStudio.name;
                        if (popup.studioBar.chip) popup.studioBar.chip.style.display = 'inline-flex';
                    }
                }

                for (const p of createdPerformers) {
                    if (typeof effectiveCtx.injectCreatedEntity === 'function') {
                        effectiveCtx.injectCreatedEntity('performers', p);
                    } else if (typeof dependencies.injectCachedEntity === 'function') {
                        dependencies.injectCachedEntity('performers', p);
                    }
                    if (popup?.performersTable && typeof popup.performersTable.addData === 'function') {
                        const rows = typeof popup.performersTable.getRows === 'function' ? popup.performersTable.getRows() : [];
                        if (!rows.some(r => String(r.getData?.()?.id) === String(p.id))) {
                            try { popup.performersTable.addData([p], true); } catch (e) {}
                        }
                        if (typeof popup.performersTable.selectRow === 'function') {
                            try { popup.performersTable.selectRow(String(p.id)); } catch (e) {}
                        }
                    }
                }

                for (const t of createdTags) {
                    if (typeof effectiveCtx.injectCreatedEntity === 'function') {
                        effectiveCtx.injectCreatedEntity('tags', t);
                    } else if (typeof dependencies.injectCachedEntity === 'function') {
                        dependencies.injectCachedEntity('tags', t);
                    }
                    if (popup?.tagsTable && typeof popup.tagsTable.addData === 'function') {
                        const rows = typeof popup.tagsTable.getRows === 'function' ? popup.tagsTable.getRows() : [];
                        if (!rows.some(r => String(r.getData?.()?.id) === String(t.id))) {
                            try { popup.tagsTable.addData([t], true); } catch (e) {}
                        }
                        if (typeof popup.tagsTable.selectRow === 'function') {
                            try { popup.tagsTable.selectRow(String(t.id)); } catch (e) {}
                        }
                    }
                }

                if (typeof effectiveCtx.fetchColumnData === 'function' && popup) {
                    if (popup.tagsTable) await effectiveCtx.fetchColumnData('tags', popup.tagsTable, '', new Set(mergedTagIds));
                    if (popup.performersTable) await effectiveCtx.fetchColumnData('performers', popup.performersTable, '', new Set(mergedPerformerIds));
                }
                if (typeof effectiveCtx.renderStudioBar === 'function') await effectiveCtx.renderStudioBar('');
                if (typeof effectiveCtx.refreshAllUI === 'function') effectiveCtx.refreshAllUI();

                await refreshSceneCards(sceneId);
                if (scrapeSelection.title || scrapeSelection.studio || scrapeSelection.performers) {
                    scheduleSceneCardRefreshAfterRename?.(sceneId, refreshSceneCards);
                }
                recordSaveUsage();
                sessionCache.delete(sceneId);

                root._fastTagEverythingScraperOpen = true;
                const acceptBtn = container ? container.querySelector('#fasttag-scrape-accept-btn') : null;
                if (acceptBtn) {
                    acceptBtn.innerHTML = resolutionFailures.length > 0
                        ? '<span>⚠ Saved</span>'
                        : (coverSaved ? '<span>✓ Saved</span>' : '<span>⚠ Saved</span>');
                    acceptBtn.disabled = true;
                    acceptBtn.style.opacity = '0.7';
                    acceptBtn.style.cursor = 'default';
                    acceptBtn.style.background = '#059669';
                    container._fastTagRecheckScraperHeaderLayout?.();
                }

                if (resolutionFailures.length > 0) {
                    const coverNote = coverSaved ? '' : ' The cover also failed to save.';
                    toastError(`Metadata saved, but FastTag could not apply: ${resolutionFailures.join(', ')}.${coverNote}`);
                } else if (coverSaved) {
                    toastSuccess(`Matched & Saved from ${scraperSourceName}!`);
                } else {
                    toastError('Metadata saved, but Stash rejected the cover image.');
                }
                return;
            } else {
                throw new Error('Scraping is only supported from Edit Everything.');
            }
        } catch (err) {
            console.error('[FastTag] Error accepting scrape match:', err);
            toastError('Failed to apply match: ' + (err?.message || err));
        }
    }


    root.FastTag = root.FastTag || {};
    root.FastTag.scraperController = Object.freeze({
        configure,
        isPopupActive,
        beginRequest,
        invalidateRequests,
        isRequestCurrent,
        watchHudOwner,
        closeHud,
        getInitialPopoutPosition,
        attachResizeHandles,
        getHudElement,
        setHudElement,
        getHudPosition,
        setHudPosition,
        getHudSize,
        setHudSize,
        getHudOwnerPopup,
        isHudOpen,
        resetLayoutState,
        getScraperHeaderDensity,
        showLoadingState,
        showAutoScrapeOffState,
        sessionCache,
        createTrigger,
        renderMatches,
        acceptMatch
    });
}(typeof window !== 'undefined' ? window : globalThis));
