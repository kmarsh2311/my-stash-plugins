# FastTag architecture

FastTag uses classic browser scripts loaded in the exact order declared in
`fasttag.yml`. Each module publishes a frozen API under `window.FastTag`; the
final `fasttag.js` file coordinates those APIs and owns browser lifecycle.

## Module ownership

- `fasttag-core.js`: pure text, time, filename, matching, and card-discovery helpers.
- `fasttag-entities.js`: entity definitions and reusable entity GraphQL operations.
- `fasttag-storage.js`: settings, IndexedDB caches, recent items, and pinned items.
- `fasttag-diagnostics.js`: debug preferences, bounded logs, exports, and global error capture.
- `fasttag-api.js`: GraphQL transport and its stable error-response contract.
- `fasttag-notifications.js`: native toast rendering, timing, dismissal, and copy controls.
- `fasttag-settings.js`: Settings HUD rendering, validation, controls, and lifecycle.
- `fasttag-integrations.js`: Apollo cache and theme-specific scene-card refreshes.
- `fasttag-gemini.js`: Gemini bridge transport, timeouts, and parsed results.
- `fasttag-scraper.js`: scraper requests, evidence scoring, ranking, and save payloads.
- `fasttag-scraper-ui.js`: scraper presentation decisions and review-state labels.
- `fasttag-scraper-controller.js`: scrape request generations, session results, result HUD rendering, detached-HUD lifecycle, and acceptance coordination.
- `fasttag-preview.js`: media discovery and rendering, scrubbing, floating video HUD lifecycle, and Cover Editor player handoff.
- `fasttag-cover-editor.js`: cover image validation, resizing, frame capture, clipboard/upload handling, and the cover-editor HUD.
- `fasttag-ui.js`: shared popup sizing and placement calculations.
- `fasttag-popup.js`: shared popup shell, persisted geometry, input containment, drag/resize handling, and close/abort lifecycle.
- `fasttag-editors.js`: selection normalization, single-editor latest-save
  ownership, shared bulk batching, and Edit Everything save snapshots/queue
  ownership.
- `fasttag-workflows.js`: reusable navigation and result-list state transitions.
- `fasttag.js`: editor popup rendering, GraphQL/effect callbacks, global event
  wiring, feature coordination, and startup.

## Change rules

1. Put pure decisions and transformations in the owning feature module and test
   them without a browser.
2. Keep DOM lookup, event binding, and orchestration in `fasttag.js` unless a
   whole view can be extracted with a small, explicit dependency interface.
3. Do not embed persistence in UI renderers. Use `fasttag-storage.js`.
4. Do not update scene cards directly from feature code. Use
   `fasttag-integrations.js`.
5. Keep entity IDs normalized as strings at editor and save boundaries.
6. Add every new module to `fasttag.yml`, the load-order contract test, and the
   unified test runner's filename convention.
7. Run `node tests/run-all.js` before staging the test plugin.

## Why the coordinator remains large

FastTag builds several interaction-heavy interfaces without a framework. Moving
DOM code merely to reduce a line count would exchange one large file for tightly
coupled modules. Extract code when it has an independently testable contract;
leave page lifecycle and wiring in the coordinator.
