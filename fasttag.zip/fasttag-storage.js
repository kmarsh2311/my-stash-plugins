(function initializeFastTagStorage(root) {
    'use strict';

    const KEYS = Object.freeze({
        theme: 'stash_fast_tag_theme',
        showIds: 'stash_fast_tag_show_ids',
        suggestions: 'stash_fast_tag_enable_suggestions',
        autoScrape: 'stash_fast_tag_auto_scrape_sequential',
        showRecent: 'fasttag_show_recent_chips',
        showPinned: 'fasttag_show_pinned_chips',
        alwaysPlayFullVideo: 'fasttag_always_play_full_video',
        cardIconClicks: 'fasttag_enable_card_icon_clicks',
        compactCoverEditor: 'fasttag_compact_cover_editor',
        geminiApiKey: 'fasttag_gemini_api_key',
        geminiModel: 'fasttag_gemini_model',
        geminiAutoParse: 'fasttag_gemini_auto_parse',
        geminiSuggestions: 'fasttag_gemini_suggestions',
        autoMarkOrganized: 'stash_fast_tag_auto_mark_organized',
        scrubSpeeds: 'fasttag_scrub_speeds',
        scrubCueCount: 'stash_fast_tag_scrub_cue_count_v6',
        videoHudOpen: 'fasttag_video_hud_open_state',
        coverEditorOpen: 'fasttag_cover_editor_open_state',
        detachScraper: 'fasttag_detach_scraper_v1',
        hideObviousFalsePositives: 'fasttag_hide_obvious_false_positives_v1',
        scraperMatching: 'fasttag_scraper_matching_settings_v1',
        fillMissingPerformerImages: 'fasttag_fill_missing_performer_images_v1',
        scraperHudOpen: 'fasttag_scraper_hud_open_state',
        defaultScraperSource: 'fasttag_default_scraper_source_v1',
        activeScraperSource: 'fasttag_active_scraper_source_v1',
        allowStashBoxFallback: 'fasttag_allow_stashbox_fallback_v1'
    });
    const RECENT_KEYS = Object.freeze({
        tags: 'stash_fast_tag_recent_tags',
        performers: 'stash_fast_tag_recent_performers',
        galleries: 'stash_fast_tag_recent_galleries',
        studios: 'stash_fast_tag_recent_studios',
        groups: 'stash_fast_tag_recent_groups'
    });
    const PINNED_PREFIX = 'stash_fast_tag_pinned_';
    const DEFAULT_SCRUB_SPEEDS = Object.freeze({
        slow: 5.0,
        normal: 10.0,
        fast: 20.0,
        freeze: 1.0
    });
    const MAX_SCRUB_CUE_DISPLAYS = 5;
    const SCRAPER_MATCHING_PRESETS = Object.freeze({
        conservative: Object.freeze({ preset: 'conservative', hideObviousFalsePositives: true, singleWordAliasMode: 'weak', majorCastConflict: false, requireStudioMismatch: true, closeDurationProtects: true, titleSimilarityThreshold: 0.1, durationMismatchThreshold: 600, durationMismatchPercent: 35, initialResultLimit: 40, allowStashBoxFallback: false, defaultScraperSource: 'stashbox_default', skipCrypticFilenames: true }),
        balanced: Object.freeze({ preset: 'balanced', hideObviousFalsePositives: true, singleWordAliasMode: 'weak', majorCastConflict: true, requireStudioMismatch: true, closeDurationProtects: true, titleSimilarityThreshold: 0.2, durationMismatchThreshold: 300, durationMismatchPercent: 25, initialResultLimit: 25, allowStashBoxFallback: false, defaultScraperSource: 'stashbox_default', skipCrypticFilenames: true }),
        strict: Object.freeze({ preset: 'strict', hideObviousFalsePositives: true, singleWordAliasMode: 'ignore', majorCastConflict: true, requireStudioMismatch: false, closeDurationProtects: false, titleSimilarityThreshold: 0.35, durationMismatchThreshold: 120, durationMismatchPercent: 15, initialResultLimit: 15, allowStashBoxFallback: false, defaultScraperSource: 'stashbox_default', skipCrypticFilenames: true })
    });
    const DEFAULT_SCRAPER_MATCHING_SETTINGS = SCRAPER_MATCHING_PRESETS.balanced;
    const IDB_NAME = 'stash_fasttag_cache_db';
    const IDB_VERSION = 1;
    const IDB_STORE = 'entity_cache';
    let idbPromise = null;

    function readBoolean(key, defaultValue) {
        const value = root.localStorage.getItem(key);
        return value === null ? defaultValue : value === 'true';
    }

    function writeBoolean(key, enabled) {
        root.localStorage.setItem(key, enabled ? 'true' : 'false');
    }

    function getAutoScrapeSequential() {
        try { return readBoolean(KEYS.autoScrape, true); } catch (e) { return true; }
    }
    function setAutoScrapeSequential(enabled) {
        try { writeBoolean(KEYS.autoScrape, enabled); } catch (e) {}
    }

    function getThemePreference() { return root.localStorage.getItem(KEYS.theme) || 'dark'; }
    function setThemePreference(theme) { root.localStorage.setItem(KEYS.theme, theme); }

    function getShowIdColumns() { return readBoolean(KEYS.showIds, true); }
    function setShowIdColumns(enabled) { writeBoolean(KEYS.showIds, enabled); }
    function getEnableSuggestions() { return readBoolean(KEYS.suggestions, true); }
    function setEnableSuggestions(enabled) { writeBoolean(KEYS.suggestions, enabled); }
    function getEnableCardIconClicks() { return readBoolean(KEYS.cardIconClicks, true); }
    function setEnableCardIconClicks(enabled) { writeBoolean(KEYS.cardIconClicks, enabled); }
    function getCompactCoverEditor() { return readBoolean(KEYS.compactCoverEditor, false); }
    function setCompactCoverEditor(enabled) { writeBoolean(KEYS.compactCoverEditor, enabled); }
    function getAlwaysPlayFullVideo() { return readBoolean(KEYS.alwaysPlayFullVideo, false); }
    function setAlwaysPlayFullVideo(enabled) { writeBoolean(KEYS.alwaysPlayFullVideo, enabled); }
    function getShowRecentChips() { return readBoolean(KEYS.showRecent, true); }
    function setShowRecentChips(enabled) { writeBoolean(KEYS.showRecent, enabled); }
    function getShowPinnedChips() { return readBoolean(KEYS.showPinned, true); }
    function setShowPinnedChips(enabled) { writeBoolean(KEYS.showPinned, enabled); }

    function getGeminiApiKey() { return root.localStorage.getItem(KEYS.geminiApiKey) || ''; }
    function setGeminiApiKey(value) { root.localStorage.setItem(KEYS.geminiApiKey, (value || '').trim()); }
    function getGeminiModel() {
        const raw = root.localStorage.getItem(KEYS.geminiModel);
        if (!raw || raw.includes('2.0') || raw.includes('1.5') || raw.includes('1.0')) {
            return 'gemini-flash-latest';
        }
        return raw;
    }
    function setGeminiModel(value) {
        const normalized = (!value || value.includes('2.0') || value.includes('1.5') || value.includes('1.0'))
            ? 'gemini-flash-latest'
            : value;
        root.localStorage.setItem(KEYS.geminiModel, normalized);
    }
    function getGeminiAutoParse() { return readBoolean(KEYS.geminiAutoParse, true); }
    function setGeminiAutoParse(enabled) { writeBoolean(KEYS.geminiAutoParse, enabled); }
    function getGeminiSuggestions() { return readBoolean(KEYS.geminiSuggestions, true); }
    function setGeminiSuggestions(enabled) { writeBoolean(KEYS.geminiSuggestions, enabled); }
    function getAutoMarkOrganized() { return root.localStorage.getItem(KEYS.autoMarkOrganized) === 'true'; }
    function setAutoMarkOrganized(enabled) { writeBoolean(KEYS.autoMarkOrganized, enabled); }

    function getScrubSpeeds() {
        try {
            const raw = root.localStorage.getItem(KEYS.scrubSpeeds);
            if (raw) {
                const parsed = JSON.parse(raw);
                return {
                    slow: Math.max(0, Math.min(30, Number(parsed.slow) !== undefined && !isNaN(Number(parsed.slow)) ? Number(parsed.slow) : DEFAULT_SCRUB_SPEEDS.slow)),
                    normal: Math.max(0, Math.min(60, Number(parsed.normal) !== undefined && !isNaN(Number(parsed.normal)) ? Number(parsed.normal) : DEFAULT_SCRUB_SPEEDS.normal)),
                    fast: Math.max(0, Math.min(120, Number(parsed.fast) !== undefined && !isNaN(Number(parsed.fast)) ? Number(parsed.fast) : DEFAULT_SCRUB_SPEEDS.fast)),
                    freeze: Math.max(0.1, Math.min(10, Number(parsed.freeze) || DEFAULT_SCRUB_SPEEDS.freeze))
                };
            }
        } catch (e) {}
        return { ...DEFAULT_SCRUB_SPEEDS };
    }

    function setScrubSpeeds(speeds) {
        root.localStorage.setItem(KEYS.scrubSpeeds, JSON.stringify(speeds));
    }

    function getScrubCueCount() {
        try {
            return parseInt(root.localStorage.getItem(KEYS.scrubCueCount) || '0', 10) || 0;
        } catch (e) {
            return 0;
        }
    }

    function incrementScrubCueCount() {
        try {
            root.localStorage.setItem(KEYS.scrubCueCount, String(getScrubCueCount() + 1));
        } catch (e) {}
    }

    function resetScrubCueCount() {
        try { root.localStorage.removeItem(KEYS.scrubCueCount); } catch (e) {}
    }

    function isVideoHudPersistedOpen() {
        try { return root.localStorage.getItem(KEYS.videoHudOpen) === 'true'; } catch (e) { return false; }
    }
    function setVideoHudPersistedOpen(enabled) {
        try { writeBoolean(KEYS.videoHudOpen, enabled); } catch (e) {}
    }
    function isCoverEditorPersistedOpen() {
        try { return root.localStorage.getItem(KEYS.coverEditorOpen) === 'true'; } catch (e) { return false; }
    }
    function setCoverEditorPersistedOpen(enabled) {
        try { writeBoolean(KEYS.coverEditorOpen, enabled); } catch (e) {}
    }
    function isScraperHudPersistedOpen() {
        try { return root.localStorage.getItem(KEYS.scraperHudOpen) === 'true'; } catch (e) { return false; }
    }
    function setScraperHudPersistedOpen(enabled) {
        try { writeBoolean(KEYS.scraperHudOpen, enabled); } catch (e) {}
    }
    function getDetachScraper() {
        try { return readBoolean(KEYS.detachScraper, true); } catch (e) { return true; }
    }
    function setDetachScraper(enabled) {
        try { writeBoolean(KEYS.detachScraper, enabled); } catch (e) {}
    }
    function getHideObviousFalsePositives() {
        return getScraperMatchingSettings().hideObviousFalsePositives;
    }
    function setHideObviousFalsePositives(enabled) {
        setScraperMatchingSettings({ hideObviousFalsePositives: Boolean(enabled), preset: 'custom' });
    }
    function getFillMissingPerformerImages() {
        try { return readBoolean(KEYS.fillMissingPerformerImages, true); } catch (e) { return true; }
    }
    function setFillMissingPerformerImages(enabled) {
        try { writeBoolean(KEYS.fillMissingPerformerImages, enabled); } catch (e) {}
    }
    function normalizeScraperMatchingSettings(settings = {}) {
        const merged = { ...DEFAULT_SCRAPER_MATCHING_SETTINGS, ...settings };
        const aliasMode = ['ignore', 'weak', 'strong'].includes(merged.singleWordAliasMode)
            ? merged.singleWordAliasMode
            : DEFAULT_SCRAPER_MATCHING_SETTINGS.singleWordAliasMode;
        const numberInRange = (value, fallback, min, max) => {
            const number = Number(value);
            return Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : fallback;
        };
        return {
            preset: ['conservative', 'balanced', 'strict', 'custom'].includes(merged.preset) ? merged.preset : 'custom',
            hideObviousFalsePositives: merged.hideObviousFalsePositives !== false,
            singleWordAliasMode: aliasMode,
            majorCastConflict: merged.majorCastConflict !== false,
            requireStudioMismatch: merged.requireStudioMismatch !== false,
            closeDurationProtects: merged.closeDurationProtects !== false,
            titleSimilarityThreshold: numberInRange(merged.titleSimilarityThreshold, 0.2, 0, 1),
            durationMismatchThreshold: Math.round(numberInRange(merged.durationMismatchThreshold, 300, 0, 3600)),
            durationMismatchPercent: Math.round(numberInRange(merged.durationMismatchPercent, 25, 0, 100)),
            initialResultLimit: Math.round(numberInRange(merged.initialResultLimit, 25, 5, 100)),
            allowStashBoxFallback: merged.allowStashBoxFallback === true,
            // Read new key; fall back to old key for users upgrading from 4.5
            skipCrypticFilenames: settings.skipCrypticFilenames !== undefined
                ? settings.skipCrypticFilenames !== false
                : (settings.skipCrypticFilenamesTPDB !== undefined ? settings.skipCrypticFilenamesTPDB !== false : true),
            defaultScraperSource: typeof merged.defaultScraperSource === 'string' ? merged.defaultScraperSource : 'stashbox_default'
        };
    }
    function getScraperMatchingSettings() {
        try {
            const raw = root.localStorage.getItem(KEYS.scraperMatching);
            if (raw) return normalizeScraperMatchingSettings(JSON.parse(raw));
            const legacyHideSetting = readBoolean(KEYS.hideObviousFalsePositives, true);
            return normalizeScraperMatchingSettings({
                preset: legacyHideSetting === DEFAULT_SCRAPER_MATCHING_SETTINGS.hideObviousFalsePositives ? 'balanced' : 'custom',
                hideObviousFalsePositives: legacyHideSetting
            });
        } catch (e) {
            return { ...DEFAULT_SCRAPER_MATCHING_SETTINGS };
        }
    }
    function setScraperMatchingSettings(settings) {
        try {
            const normalized = normalizeScraperMatchingSettings({ ...getScraperMatchingSettings(), ...(settings || {}) });
            root.localStorage.setItem(KEYS.scraperMatching, JSON.stringify(normalized));
            writeBoolean(KEYS.hideObviousFalsePositives, normalized.hideObviousFalsePositives);
            return normalized;
        } catch (e) {
            return getScraperMatchingSettings();
        }
    }
    function setScraperMatchingPreset(presetName) {
        const preset = SCRAPER_MATCHING_PRESETS[presetName] || DEFAULT_SCRAPER_MATCHING_SETTINGS;
        return setScraperMatchingSettings(preset);
    }
    function resetScraperMatchingSettings() {
        return setScraperMatchingPreset('balanced');
    }
    function getSkipCrypticFilenames() {
        return getScraperMatchingSettings().skipCrypticFilenames !== false;
    }
    function setSkipCrypticFilenames(enabled) {
        setScraperMatchingSettings({
            skipCrypticFilenames: Boolean(enabled),
            skipCrypticFilenamesTPDB: Boolean(enabled),
            preset: 'custom'
        });
    }

    
    function getDefaultScraperSource() {
        try {
            const fromSettings = getScraperMatchingSettings().defaultScraperSource;
            if (fromSettings) return fromSettings;
            return root.localStorage.getItem(KEYS.defaultScraperSource) || 'stashbox_default';
        } catch (e) {
            return 'stashbox_default';
        }
    }
    function setDefaultScraperSource(sourceId) {
        try {
            const val = String(sourceId || 'stashbox_default');
            root.localStorage.setItem(KEYS.defaultScraperSource, val);
            setScraperMatchingSettings({ defaultScraperSource: val, preset: 'custom' });
            if (val !== 'remember_last') {
                root.localStorage.removeItem(KEYS.activeScraperSource);
            }
            return val;
        } catch (e) {
            return 'stashbox_default';
        }
    }
    function getActiveScraperSource() {
        try {
            return root.localStorage.getItem(KEYS.activeScraperSource) || null;
        } catch (e) {
            return null;
        }
    }
    function setActiveScraperSource(sourceId) {
        try {
            if (!sourceId) {
                root.localStorage.removeItem(KEYS.activeScraperSource);
                return null;
            }
            const val = String(sourceId);
            root.localStorage.setItem(KEYS.activeScraperSource, val);
            return val;
        } catch (e) {
            return null;
        }
    }
    function getAllowStashBoxFallback() {
        return getScraperMatchingSettings().allowStashBoxFallback === true;
    }
    function setAllowStashBoxFallback(enabled) {
        setScraperMatchingSettings({ allowStashBoxFallback: Boolean(enabled), preset: 'custom' });
    }

    function getIDB() {
        if (typeof root.indexedDB === 'undefined') return Promise.resolve(null);
        if (idbPromise) return idbPromise;
        idbPromise = new Promise((resolve) => {
            try {
                const req = root.indexedDB.open(IDB_NAME, IDB_VERSION);
                req.onupgradeneeded = (event) => {
                    const db = event.target.result;
                    if (!db.objectStoreNames.contains(IDB_STORE)) {
                        db.createObjectStore(IDB_STORE, { keyPath: 'type' });
                    }
                };
                req.onsuccess = (event) => resolve(event.target.result);
                req.onerror = (error) => {
                    console.warn('[FastTag] IndexedDB open error, falling back to memory cache:', error);
                    resolve(null);
                };
            } catch (error) {
                console.warn('[FastTag] IndexedDB initialization failed:', error);
                resolve(null);
            }
        });
        return idbPromise;
    }

    async function idbGet(type) {
        try {
            const db = await getIDB();
            if (!db) return null;
            return new Promise((resolve) => {
                const req = db.transaction(IDB_STORE, 'readonly').objectStore(IDB_STORE).get(type);
                req.onsuccess = () => resolve(req.result || null);
                req.onerror = () => resolve(null);
            });
        } catch (e) {
            return null;
        }
    }

    async function idbSet(type, data, timestamp = Date.now()) {
        try {
            const db = await getIDB();
            if (!db) return;
            db.transaction(IDB_STORE, 'readwrite').objectStore(IDB_STORE).put({ type, data, timestamp });
        } catch (error) {
            console.warn('[FastTag] Error writing to IndexedDB:', error);
        }
    }

    async function idbDelete(type) {
        try {
            const db = await getIDB();
            if (!db) return;
            const store = db.transaction(IDB_STORE, 'readwrite').objectStore(IDB_STORE);
            if (type) store.delete(type);
            else store.clear();
        } catch (e) {}
    }

    function readPinnedEntries(type) {
        try {
            const raw = root.localStorage.getItem(PINNED_PREFIX + type);
            const parsed = raw ? JSON.parse(raw) : [];
            return Array.isArray(parsed) ? parsed : [];
        } catch (e) {
            return [];
        }
    }

    function writePinnedEntries(type, value) {
        try {
            root.localStorage.setItem(PINNED_PREFIX + type, JSON.stringify(Array.isArray(value) ? value : []));
        } catch (e) {}
    }

    function readRecentEntries(type) {
        try {
            const key = RECENT_KEYS[type];
            if (!key) return [];
            const raw = root.localStorage.getItem(key);
            const parsed = raw ? JSON.parse(raw) : [];
            return Array.isArray(parsed) ? parsed : [];
        } catch (e) {
            return [];
        }
    }

    function writeRecentEntries(type, value) {
        try {
            const key = RECENT_KEYS[type];
            if (!key) return;
            root.localStorage.setItem(key, JSON.stringify((Array.isArray(value) ? value : []).slice(0, 24)));
        } catch (e) {}
    }

    function addRecentEntry(type, item) {
        if (!item) return;
        const name = item.name || item.title;
        if (!name) return;
        const list = readRecentEntries(type).filter(entry => entry && (entry.name || entry.title) && (entry.name || entry.title) !== name);
        list.unshift({ id: item.id, name });
        writeRecentEntries(type, list);
    }

    function addRecentEntriesFromSelection(type, selectedItems) {
        if (!Array.isArray(selectedItems)) return;
        selectedItems.filter(Boolean).forEach(item => addRecentEntry(type, item));
    }

    root.FastTag = root.FastTag || {};
    root.FastTag.storage = Object.freeze({
        getAutoScrapeSequential,
        setAutoScrapeSequential,
        getThemePreference,
        setThemePreference,
        getShowIdColumns,
        setShowIdColumns,
        getEnableSuggestions,
        setEnableSuggestions,
        getEnableCardIconClicks,
        setEnableCardIconClicks,
        getCompactCoverEditor,
        setCompactCoverEditor,
        getAlwaysPlayFullVideo,
        setAlwaysPlayFullVideo,
        getShowRecentChips,
        setShowRecentChips,
        getShowPinnedChips,
        setShowPinnedChips,
        getGeminiApiKey,
        setGeminiApiKey,
        getGeminiModel,
        setGeminiModel,
        getGeminiAutoParse,
        setGeminiAutoParse,
        getGeminiSuggestions,
        setGeminiSuggestions,
        getAutoMarkOrganized,
        setAutoMarkOrganized,
        DEFAULT_SCRUB_SPEEDS,
        MAX_SCRUB_CUE_DISPLAYS,
        getScrubSpeeds,
        setScrubSpeeds,
        getScrubCueCount,
        incrementScrubCueCount,
        resetScrubCueCount,
        isVideoHudPersistedOpen,
        setVideoHudPersistedOpen,
        isCoverEditorPersistedOpen,
        setCoverEditorPersistedOpen,
        isScraperHudPersistedOpen,
        setScraperHudPersistedOpen,
        getDetachScraper,
        setDetachScraper,
        getHideObviousFalsePositives,
        setHideObviousFalsePositives,
        getFillMissingPerformerImages,
        setFillMissingPerformerImages,
        SCRAPER_MATCHING_PRESETS,
        DEFAULT_SCRAPER_MATCHING_SETTINGS,
        getScraperMatchingSettings,
        setScraperMatchingSettings,
        setScraperMatchingPreset,
        resetScraperMatchingSettings,
        getSkipCrypticFilenames,
        setSkipCrypticFilenames,
        getDefaultScraperSource,
        setDefaultScraperSource,
        getActiveScraperSource,
        setActiveScraperSource,
        getAllowStashBoxFallback,
        setAllowStashBoxFallback,
        idbGet,
        idbSet,
        idbDelete,
        readPinnedEntries,
        writePinnedEntries,
        readRecentEntries,
        writeRecentEntries,
        addRecentEntry,
        addRecentEntriesFromSelection
    });
}(typeof window !== 'undefined' ? window : globalThis));
